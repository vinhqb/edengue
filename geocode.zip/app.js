document.getElementById('processCsv').addEventListener('click', processCsv);

async function processCsv() {
    const fileInput = document.getElementById('csvFileInput');
    if (!fileInput.files.length) {
        alert('Please select a CSV file.');
        return;
    }

    const file = fileInput.files[0];
    const text = await file.text();
    const csvData = parseCsv(text);

    for (const row of csvData) {
        const address = row.address;
        const coordinates = await geocodeAddress(address);
        if (!coordinates) {
            const fallbackAddress = getFallbackAddress(address);
            await displayMapForManualSelection(fallbackAddress, row);
            /*
            const fallbackAddress = getFallbackAddress(address);
            const fallbackCoordinates = await geocodeAddress(fallbackAddress);
            if (!fallbackCoordinates) {
                alert(`Geocoding failed for address: ${address}. Please select manually on the map.`);
                await displayMapForManualSelection(fallbackAddress, row);
            } else {
                await displayMapForManualSelection(fallbackAddress, row, fallbackCoordinates);
            }
            */
        } else {
            row.lat = coordinates.lat;
            row.lon = coordinates.lon;
        }
    }

    // Save updated CSV data
    saveCsv(csvData);
}

function parseCsv(text) {
    // Parse CSV text and return an array of objects
    const rows = text.split('\n').filter(row => row.trim() !== '');
    const header = rows[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const data = rows.slice(1).map(row => {
        const values = row.split(',').map(value => value.trim().replace(/^"|"$/g, ''));
        return header.reduce((obj, header, index) => {
            obj[header] = values[index];
            return obj;
        }, {});
    });
    return data;
}

async function geocodeAddress(address) {
    // Call OpenStreetMap Nominatim API
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json`);
        const data = await response.json();
        if (data && data.length) {
            return {
                lat: parseFloat(data[0].lat),
                lon: parseFloat(data[0].lon)
            };
        }
        return null;
    } catch (error) {
        console.error('Geocoding error:', error);
        return null;
    }
}

function getFallbackAddress(address) {
    // Simplify the address to a broader area (e.g., district or city)
    const parts = address.split(',');
    if (parts.length > 1) {
        return parts.slice(1).join(',');
    }
    return address;
}

function displayMapForManualSelection(address, row, coordinates = null) {
    return new Promise((resolve) => {
        const map = new ol.Map({
            target: 'map',
            layers: [
                new ol.layer.Tile({
                    source: new ol.source.OSM()
                })
            ],
            view: new ol.View({
                center: coordinates ? ol.proj.fromLonLat([coordinates.lon, coordinates.lat]) : ol.proj.fromLonLat([106.660172, 10.762622]),
                zoom: 12
            })
        });

        map.on('click', function (e) {
            const coordinates = ol.proj.toLonLat(e.coordinate);
            row.lat = coordinates[1];
            row.lon = coordinates[0];
            alert(`Coordinates selected: ${coordinates[1]}, ${coordinates[0]}`);
            resolve();
        });
    });
}

function saveCsv(data) {
    const header = Object.keys(data[0]).join(',');
    const rows = data.map(row => {
        return Object.values(row).map((value, index) => {
            if (index === 0) {
                return `"${value}"`;
            }
            return value;
        }).join(',');
    });
    const csvContent = [header, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'updated_addresses.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
