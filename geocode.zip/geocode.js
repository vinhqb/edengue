document.getElementById('processCsv').addEventListener('click', processCsv);

async function processCsv() {
    const fileInput = document.getElementById('csvFileInput');
    if (!fileInput.files.length) {
        alert('Please select a CSV file.');
        return;
    }

    const file = fileInput.files[0];
    const text = await file.text();
    const csvData = parseCsv(text);
    
    const statusElement = document.getElementById('status');
    
    for (const row of csvData) {
        const address = row.address;
        updateStatus(`Processing address: ${address}`);
        const coordinates = await geocodeAddress(address);
        
        if (!coordinates) {
            const fallbackAddress = getFallbackAddress(address);
            updateStatus(`Geocoding failed for address: ${address}. Using fallback address: ${fallbackAddress}`);
            await displayMapForManualSelection(fallbackAddress, row, address);
        } else {
            row.lat = coordinates.lat;
            row.lon = coordinates.lon;
        }

        // Adding delay of 1 second between requests
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Save updated CSV data
    saveCsv(csvData);
    updateStatus('Processing complete.');
}
/*
function parseCsv(text) {
    // Parse CSV text and return an array of objects
    const rows = text.split('\n').filter(row => row.trim() !== '');
    const header = rows[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const data = rows.slice(1).map(row => {
        const values = row.split(',').map(value => value.trim().replace(/^"|"$/g, ''));
        return header.reduce((obj, header, index) => {
            obj[header] = values[index];
            return obj;
        }, {});
    });
    return data;
}
*/

function parseCsv(text) {
    const rows = [];
    const regex = /(".*?"|[^,"]+)(?=\s*,|\s*$)/g; // Regex to handle quoted values and commas

    const lines = text.split('\n').filter(row => row.trim() !== '');
    const header = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        const values = [];
        let match;
        while ((match = regex.exec(line)) !== null) {
            values.push(match[0].replace(/^"|"$/g, '')); // Remove surrounding quotes
        }
        if (values.length > 0) {
            const row = header.reduce((obj, header, index) => {
                obj[header] = values[index] || '';
                return obj;
            }, {});
            rows.push(row);
        }
    }
    return rows;
}

async function geocodeAddress(address) {
    // Call OpenStreetMap Nominatim API
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json`);
        const data = await response.json();
        if (data && data.length) {
            return {
                lat: parseFloat(data[0].lat),
                lon: parseFloat(data[0].lon)
            };
        }
        return null;
    } catch (error) {
        console.error('Geocoding error:', error);
        return null;
    }
}

function getFallbackAddress(address) {
    // Simplify the address to a broader area (e.g., district or city)
    const parts = address.split(',');
    if (parts.length > 1) {
        return parts.slice(1).join(',');
    }
    return address;
}

function updateStatus(message) {
    // Update the status element with the current message
    const statusElement = document.getElementById('status');
    if (statusElement) {
        statusElement.textContent = message;
    }
}

function displayMapForManualSelection(fallbackAddress, row, originalAddress) {
    return new Promise(async (resolve) => {
        // Fetch coordinates for fallback address to center the map
        const fallbackCoordinates = await geocodeAddress(fallbackAddress);
        const centerCoordinates = fallbackCoordinates ? ol.proj.fromLonLat([fallbackCoordinates.lon, fallbackCoordinates.lat]) : ol.proj.fromLonLat([106.660172, 10.762622]);

        const map = new ol.Map({
            target: 'map',
            layers: [
                new ol.layer.Tile({
                    source: new ol.source.OSM()
                })
            ],
            view: new ol.View({
                center: centerCoordinates,
                zoom: 12
            })
        });

        map.on('click', function (e) {
            const selectedCoordinates = ol.proj.toLonLat(e.coordinate);
            row.lat = selectedCoordinates[1];
            row.lon = selectedCoordinates[0];
            updateStatus(`Coordinates selected for original address: ${originalAddress}. Selected coordinates: ${selectedCoordinates[1]}, ${selectedCoordinates[0]}`);
            resolve();
        });
    });
}


function saveCsv(data) {
    const header = Object.keys(data[0]).join(',');
    const rows = data.map(row => {
        return Object.values(row).map((value, index) => {
            if (index === 0) {
                return `"${value}"`;
            }
            return value;
        }).join(',');
    });
    const csvContent = [header, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'updated_addresses.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
