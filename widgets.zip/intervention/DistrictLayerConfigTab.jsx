import React from "react";

const DistrictLayerConfigTab = ({ config, setConfig, loading }) => {
    
  const coerceType = (key, value) => {
    const numberFields = ["method", "t_threshold", "horizon"];
    const floatFields = ["p_threshold"];
    const booleanFields = ["boundary"];
    
    // Treat date as a string in "YYYY-MM-DD" format
    if (numberFields.includes(key)) return parseInt(value, 10);
    if (floatFields.includes(key)) return parseFloat(value);
    if (booleanFields.includes(key)) return Boolean(value);
  
    return value; // fallback: keep as string
  };
  
  const handleConfigChange = (e) => {
    const { name, type, value, checked } = e.target;
    setConfig((prev) => ({
      ...prev,
      [name]: coerceType(name, type === "checkbox" ? checked : value),
    }));
  };
  
  return (
    <div style={{ marginBottom: "10px", background: "#f5f5f5", padding: "10px", borderRadius: "5px" }}>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
        {[
          { label: "Target date", name: "date", type: "date", width: "160px" },
          { label: "Prob. Threshold", name: "p_threshold", min: 0, max: 1, step: 0.1, type: "number", width: "120px" },
          { label: "Tollerance", name: "t_threshold", min: 0, step: 1, type: "number", width: "80px" },
        ].map(({ label, name, min, max, step, type, width }) => (
          <div key={name} style={{ display: "flex", flexDirection: "column", width }}>
            <label>{label}:</label>
            <input
              type={type}
              name={name}
              value={config[name] || ""}
              min={min}
              max={max}
              step={step}
              onChange={handleConfigChange}
              disabled={loading}
              style={{ width }}
            />
          </div>
        ))}
        
        <div style={{ display: "flex", flexDirection: "column" }}>
          <label>Method:</label>
          <select
            name="method"
            value={config.method}
            onChange={handleConfigChange}
            disabled={loading}
          >
            <option value="1">Prediction mean</option>
            <option value="2">Absolute score</option>
            <option value="3">Z-Score</option>
            <option value="4">Combined</option>
          </select>
        </div>

        <div style={{ display: "flex", flexDirection: "column" }}>
          <label>Forecast Horizon:</label>
          <select
            name="horizon"
            value={config.horizon}
            onChange={handleConfigChange}
            disabled={loading}
          >
            <option value="1">1 month</option>
            <option value="2">2 months</option>
            <option value="3">3 months</option>
          </select>
        </div>

        <div style={{ display: "flex", flexDirection: "column" }}>
          <label>Boundary:</label>
          <input 
            type="checkbox"
            name="boundary"
            checked={config.boundary} 
            onChange={handleConfigChange}
            disabled={loading}
          />
        </div>

       </div>
    </div>
  );
};

export default DistrictLayerConfigTab;


