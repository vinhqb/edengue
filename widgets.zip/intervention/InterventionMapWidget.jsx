import React, { useEffect, useRef, useState, useCallback } from "react";
import { FaCog, FaTimes, FaSyncAlt, FaDownload } from "react-icons/fa";
import { Map, View } from "ol";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import { fromLonLat } from "ol/proj";
import ResizeObserver from "resize-observer-polyfill";
import MapUtils from "./InterventionMapUtils";
import CommuneLayerConfigTab from "./CommuneLayerConfigTab";
import DistrictLayerConfigTab from "./DistrictLayerConfigTab";
import useLayerInteraction from "./LayerInteractionTooltip";
import LayerManager from "./LayerManager";
import InterventionMapUtils from "./InterventionMapUtils";
import { defaultDistrictConfig, defaultCommuneConfig, LAYER_KEYS } from "./LayerConfig";
import styles from "./styles.module.css";

// add map legend for each layer
const districtMapLegend = [
  { color: "green", label: "0–20 predicted cases" },
  { color: "yellow", label: "21–50 predicted cases" },
  { color: "orange", label: "51–70 predicted cases" },
  { color: "red", label: "71+ predicted cases" },
  // { color: "green", label: "low risk" },
  // { color: "yellow", label: "medium risk" },
  // { color: "red", label: "high risk" },
]
  
const communeMapLegend = [
  { color: "green", label: "0–20 cases" },
  { color: "yellow", label: "21–50 cases" },
  { color: "orange", label: "51–70 cases" },
  { color: "red", label: "71+ cases" },
]

const layerLegends = {
  [LAYER_KEYS.DISTRICT]: districtMapLegend,
  [LAYER_KEYS.COMMUNE]: communeMapLegend,  
};

const layerLoaders = {
  [LAYER_KEYS.DISTRICT]: InterventionMapUtils.loadDistrictLayer,
  [LAYER_KEYS.COMMUNE]: InterventionMapUtils.loadCommuneLayer,
};

const layerStyles = {
  [LAYER_KEYS.DISTRICT]: InterventionMapUtils.districtStyleFunction,
  [LAYER_KEYS.COMMUNE]: InterventionMapUtils.communeStyleFunction,
};


const InterventionMapWidget = ({ title, onRemove }) => {
  const mapRef = useRef();
  const olMapRef = useRef();
  
  const [configOpen, setConfigOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState(LAYER_KEYS.DISTRICT);

  const layerConfigComponents = {
    [LAYER_KEYS.DISTRICT]: DistrictLayerConfigTab,    
    [LAYER_KEYS.COMMUNE]: CommuneLayerConfigTab,
  };
  
  const defaultConfigs = {
    [LAYER_KEYS.DISTRICT]: defaultDistrictConfig,    
    [LAYER_KEYS.COMMUNE]: defaultCommuneConfig,
  };

  const [layerConfigs, setLayerConfigs] = useState(defaultConfigs);
  const { getLayer } = LayerManager;

  const applyLayerConfig = useCallback((key) => {
    if (olMapRef.current && typeof layerLoaders[key] === "function") {
      setLoading(true);

      // Timeout fallback in case data load hangs
      const timeoutId = setTimeout(() => {
        setLoading(false);
        alert(`Loading timeout for layer "${key}"`);
        console.warn(`Loading timeout for layer "${key}"`);
      }, 120000); // 120 seconds

      layerLoaders[key](olMapRef.current, layerConfigs[key], (success = true) => {
        clearTimeout(timeoutId);
        setLoading(!success); // Assume false disables loading if fetch fails
      });
    }
  }, [layerConfigs]);

  
  useEffect(() => {
    const mapContainer = mapRef.current;
    olMapRef.current = new Map({
      target: mapContainer,
      layers: [new TileLayer({ source: new OSM() })],
      view: new View({
        center: fromLonLat([106.0, 10.0]),
        zoom: 7,
        projection: "EPSG:3857",
      }),
    });

    const resizeObserver = new ResizeObserver(() => {
      if (olMapRef.current) olMapRef.current.updateSize();
    });

    if (mapContainer) resizeObserver.observe(mapContainer);

    return () => {
      if (mapContainer) resizeObserver.unobserve(mapContainer);     
      if (olMapRef.current) olMapRef.current.setTarget(null);
    };
  }, []);

  //Prevent effect from firing on mount
  const didMountRef = useRef(false);
  useEffect(() => {
    if (didMountRef.current) {
      Object.keys(layerConfigs).forEach((key) => {
        if (layerConfigs[key].visible) {
          applyLayerConfig(key);
        }
      });
    } else {
      didMountRef.current = true;
    }
  }, [layerConfigs, applyLayerConfig]);

  useEffect(() => {
    const boundaryLayerKey = `${activeTab}_boundary`;
    const layer = getLayer(boundaryLayerKey);
    const hasBoundaryConfig = layerConfigs[activeTab]?.boundary;
  
    if (hasBoundaryConfig) {
      if (layer) {
        layer.setVisible(true);
      } else {
        applyLayerConfig(activeTab);
      }
    } else {
      if (layer) {
        layer.setVisible(false);
      }
    }
  }, [activeTab, getLayer, layerConfigs, applyLayerConfig]);
  
  // const updateLayerConfig = (key, newConfig) => {
  //   setLayerConfigs((prev) => ({ ...prev, [key]: newConfig }));
  // };

  // const updateLayerConfig = (key, newConfig) => {
  //   setLayerConfigs((prev) => ({
  //     ...prev,
  //     [key]: {
  //       ...prev[key], // retain the existing properties for the active layer
  //       ...newConfig, // merge in the new properties (from the panel)
  //     },
  //   }));
  // };
  

  useEffect(() => {
    Object.keys(layerConfigs).forEach((layerId) => {
      const layer = getLayer(layerId);
      if (!layer) return;
  
      if (layerId === activeTab) {
        layer.setStyle(layerStyles[layerId]);
      } else {
        layer.setStyle(InterventionMapUtils.boundaryLayerStyleFunction);
      }
    });
  }, [activeTab, layerConfigs, getLayer]);
  
  const updateLayerConfig = (key, updater) => {
    setLayerConfigs((prev) => ({
      ...prev,
      [key]: typeof updater === "function" ? updater(prev[key]) : updater,
    }));
  };
    
  const ActiveLayerComponent = layerConfigComponents[activeTab];
  
  //Add interactions
  useLayerInteraction({
    map: olMapRef.current,
    layerId: LAYER_KEYS.DISTRICT,
    getLayer: () => getLayer(LAYER_KEYS.DISTRICT),
    onHover: InterventionMapUtils.handleDistrictHover,
    onClick: InterventionMapUtils.handleDistrictClick,
    getTooltipContent: InterventionMapUtils.getDistrictTooltip, 
    active: activeTab === LAYER_KEYS.DISTRICT,
  });
  
  useLayerInteraction({
    map: olMapRef.current,
    layerId: LAYER_KEYS.COMMUNE,
    getLayer: () => getLayer(LAYER_KEYS.COMMUNE),
    onHover: InterventionMapUtils.handleCommuneHover,
    onClick: InterventionMapUtils.handleCommuneClick,
    getTooltipContent: InterventionMapUtils.getCommuneTooltip,    
    active: activeTab === LAYER_KEYS.COMMUNE,
  });


  return (
    <>
      <div className="widget-header">
        <button onClick={() => setConfigOpen(!configOpen)} onTouchStart={() => setConfigOpen(!configOpen)} className="config-button" title="Configure">
          <FaCog />
        </button>
        <div className="widget-title">{title}</div>
        <button onClick={onRemove} onTouchStart={onRemove} className="remove-button" title="Remove">
          <FaTimes />
        </button>
      </div>

      <div className="widget-content" style={{ width: "100%", height: "100%", boxSizing: "border-box" }}>
        {configOpen && (
          <div
            style={{
              marginBottom: "10px",
              background: "#f5f5f5",
              padding: "10px",
              borderRadius: "5px",
            }}
          >
          {/* Tab component*/}
          <div style={{ borderBottom: "1px solid #ccc", display: "flex" }}>
            {Object.keys(layerConfigs).map((key) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                style={{
                  padding: "8px 16px",
                  backgroundColor: activeTab === key ? "#fff" : "#e0e0e0",
                  border: "1px solid #ccc",
                  borderBottom: activeTab === key ? "none" : "1px solid #ccc",
                  borderTopLeftRadius: "8px",
                  borderTopRightRadius: "8px",
                  borderBottomLeftRadius: "0",
                  borderBottomRightRadius: "0",
                  fontWeight: activeTab === key ? "bold" : "normal",
                  marginRight: "-1px",
                  marginBottom: "-1px",
                  zIndex: activeTab === key ? 2 : 1,
                  position: "relative",
                  cursor: "pointer",
                      }}
              >
                  {key.charAt(0).toUpperCase() + key.slice(1)}
                </button>
              ))}
            </div>
            {/* Config panel component*/}
            <div style={{  
              border: "1px solid #ccc", 
              borderTop: "none", 
              borderRadius: "0 0 8px 8px",  
              backgroundColor: "#fff", 
              padding: "10px", 
              display: "flex", 
              alignItems: "center", 
              gap: "20px", 
              flexWrap: "wrap" }}>
              <ActiveLayerComponent
                config={layerConfigs[activeTab]}
                setConfig={(newCfg) => updateLayerConfig(activeTab, newCfg)}
                loading={loading}
              />            
              <div style={{ marginTop: "0px", display: "flex", gap: "10px" }}>
                <button
                  onClick={() => applyLayerConfig(activeTab)}
                  disabled={loading}
                  className="p-2 rounded-full hover:bg-gray-200 transition"
                  title="Refresh Data"
                >
                  <FaSyncAlt size={16} />
                </button>
                <button
                  onClick={() => MapUtils.downloadLayerData(olMapRef.current, layerConfigs[activeTab].layerid, `intervention_${activeTab}.csv`)}
                  className="p-2 rounded-full hover:bg-gray-200 transition"
                  title="Download CSV"
                  disabled={loading}
                >
                  <FaDownload size={16} />
                </button>
              </div>
            </div>            
          </div>
        )}
        {/* Map component*/}
        <div
          ref={mapRef}
          style={{
            position: "relative",
            width: "100%",
            height: configOpen ? "calc(100% - 150px)" : "100%",
            backgroundColor: "#ddd",
            boxSizing: "border-box",
          }}
        >
          {loading && (
            <div
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: "rgba(255,255,255,0.7)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 1000,
                fontWeight: "bold",
              }}
            >
              Loading data...
            </div>
          )}
        </div>
      </div>

      <div className={styles["map-legend"]}>
        {layerLegends[activeTab]?.map(({ color, label }, idx) => (
            <div key={idx}>
              <span className={styles["legend-color"]} style={{ backgroundColor: color }}></span> {label}
            </div>
        ))}        
      </div>
    </>
  );
};

export default InterventionMapWidget;