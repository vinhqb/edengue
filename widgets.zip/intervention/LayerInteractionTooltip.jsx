import { useEffect, useRef } from 'react';
import { Overlay } from 'ol';
import { Style, Stroke, Fill } from 'ol/style';

// Define hover style
const hoverStyle = new Style({
  stroke: new Stroke({ color: 'orange', width: 2 }),
  fill: new Fill({ color: 'rgba(255, 165, 0, 0.2)' }),
});

/**
 * Hook for pointer interaction with optional tooltip and hover styling.
 *
 * @param {Object} options
 * @param {ol/Map} options.map - OpenLayers Map instance.
 * @param {string} options.layerId - Unique identifier for the layer.
 * @param {Function} options.getLayer - () => VectorLayer, returns the current target layer.
 * @param {Function} [options.getTooltipContent] - (feature) => string or HTMLElement.
 * @param {Function} [options.onHover] - (feature|null, coordinate) => void.
 * @param {Function} [options.onClick] - (feature, coordinate) => void.
 * @param {boolean} options.active - Whether the interaction is active.
 */
export default function useLayerInteraction({
  map,
  layerId,
  getLayer,
  getTooltipContent,
  onHover,
  onClick,
  active,
}) {
  const hoveredFeatureRef = useRef(null);
  const tooltipOverlayRef = useRef(null);

  useEffect(() => {
    if (!map || !active) return;

    const layer = getLayer();
    if (!layer) return;

    // Create tooltip overlay
    const tooltipEl = document.createElement('div');
    tooltipEl.className = 'ol-tooltip';
    tooltipEl.style.cssText = `
      position: absolute;
      background: white;
      border: 1px solid gray;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 12px;
      pointer-events: none;
      white-space: nowrap;
    `;

    const tooltipOverlay = new Overlay({
      element: tooltipEl,
      offset: [10, 0],
      positioning: 'bottom-left',
    });
    map.addOverlay(tooltipOverlay);
    tooltipOverlayRef.current = tooltipOverlay;

    const handlePointerMove = (evt) => {
      let currentFeature = null;

      map.forEachFeatureAtPixel(evt.pixel, (feature, layerCandidate) => {
        if (layerCandidate === layer) {
          currentFeature = feature;
          return true;
        }
      });

      // Update cursor
      const targetEl = map.getTargetElement();
      if (targetEl) {
        targetEl.style.cursor = currentFeature ? 'pointer' : '';
      }

      // Update feature hover style
      if (hoveredFeatureRef.current && hoveredFeatureRef.current !== currentFeature) {
        hoveredFeatureRef.current.setStyle(null);
      }

      if (currentFeature && currentFeature !== hoveredFeatureRef.current) {
        currentFeature.setStyle(hoverStyle);
      }

      hoveredFeatureRef.current = currentFeature;

      // Tooltip
      if (currentFeature && getTooltipContent) {
        const content = getTooltipContent(currentFeature);
        tooltipEl.innerHTML = typeof content === 'string' ? content : '';
        tooltipOverlay.setPosition(evt.coordinate);
        tooltipEl.style.display = 'block';
      } else {
        tooltipEl.style.display = 'none';
      }

      if (onHover) 
        onHover(currentFeature);
        //onHover(currentFeature, evt.coordinate);
    };

    const handleClick = (evt) => {
      if (!onClick) return;
      map.forEachFeatureAtPixel(evt.pixel, (feature, layerCandidate) => {
        if (layerCandidate === layer) {
          //onClick(feature, evt.coordinate);
          onClick(feature, map);
        }
      });
    };

    map.on('pointermove', handlePointerMove);
    map.on('click', handleClick);

    return () => {
      map.un('pointermove', handlePointerMove);
      map.un('click', handleClick);
      if (tooltipOverlayRef.current) {
        map.removeOverlay(tooltipOverlayRef.current);
        tooltipOverlayRef.current = null;
      }
      if (hoveredFeatureRef.current) {
        hoveredFeatureRef.current.setStyle(null);
        hoveredFeatureRef.current = null;
      }
    };
  }, [map, getLayer, getTooltipContent, onHover, onClick, active, layerId]);
}
