import Utils from "../Utils";

export const LAYER_KEYS = {
  DISTRICT: "district",
  COMMUNE: "commune",
};

export const defaultDistrictConfig = {
    layerid: [LAYER_KEYS.DISTRICT],
    url: Utils.API_BASE_URL + "/intervention/districts",
    date: `${new Date(new Date().getFullYear(), new Date().getMonth() + 2, 1).getFullYear()}-${String(new Date(new Date().getFullYear(), new Date().getMonth() + 2, 1).getMonth() + 1).padStart(2, '0')}-01`,
    horizon: 3,
    p_threshold: 0.1,
    t_threshold: 20,    
    method: 4,
    boundary: true,
    boundary_url: Utils.API_BASE_URL + "/boundary/districts",
    visible: false,
}

export const defaultCommuneConfig = {
  layerid: [LAYER_KEYS.COMMUNE],
  url: Utils.API_BASE_URL + "/intervention/communes",
  start_year: 2018,
  end_year: 2022,
  month: new Date().getMonth() + 1,
  threshold: 0.5,
  boundary: true,
  boundary_url: Utils.API_BASE_URL + "/boundary/communes",  
  visible: false,
}
