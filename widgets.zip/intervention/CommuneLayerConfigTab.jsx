import React from "react";

const CommuneLayerConfigTab = ({ config, setConfig, loading }) => {



  const coerceType = (key, value) => {
    const numberFields = ["start_year", "start_year", "month"];
    const floatFields = ["p_threshold"];
    const booleanFields = ["boundary"];
  
    if (numberFields.includes(key)) return parseInt(value, 10);
    if (floatFields.includes(key)) return parseFloat(value);
    if (booleanFields.includes(key)) return Boolean(value);

    return value; // fallback: keep as string
  };
 
  
  const handleConfigChange = (e) => {
    const { name, type, value, checked } = e.target;
    
    setConfig((prev) => ({
      ...prev,
      [name]: coerceType(name, type === 'checkbox' ? checked : value),
    }));
  };


  return (
    <div style={{ marginBottom: "10px", background: "#f5f5f5", padding: "10px", borderRadius: "5px" }}>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
        {[
          { label: "Start Year", name: "start_year", min: 2004, step: 1, width: "80px" },
          { label: "End Year", name: "end_year", min: 2004, step: 1, width: "80px" },
          { label: "Month", name: "month", min: 1, max: 12, step: 1, width: "80px" },
          { label: "Threshold", name: "threshold", min: 0, max: 1, step: 0.1, width: "80px" },
        ].map(({ label, name, min, max, step, width }) => (
          <div key={name} style={{ display: "flex", flexDirection: "column", width }}>
            <label>{label}:</label>
            <input
              type="number"
              name={name}
              value={config[name]}
              min={min}
              max={max}
              step={step}
              onChange={handleConfigChange}
              disabled={loading}
              style={{ width }}
            />
          </div>
        ))}

          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>Boundary:</label>
            <input 
              type="checkbox"
              name="boundary"
              checked={config.boundary} 
              onChange={handleConfigChange}
              disabled={loading}
            />
          </div>
      </div>
    </div>
  );
};

export default CommuneLayerConfigTab;


