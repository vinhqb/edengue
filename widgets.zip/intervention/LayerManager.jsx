// LayerManager.js — stateless, map passed to functions

const olLayers = {}; // shared layer dictionary

const LayerManager = {
  addLayer: (layerid, layer, map) => {
    if (!olLayers[layerid]) {
      map?.addLayer(layer);
      olLayers[layerid] = layer;
    } else {
      console.warn(`LayerManager: Layer with ID "${layerid}" already exists`);
      return olLayers[layerid];      
    }
  },

  removeLayer: (layerid, map) => {
    const layer = olLayers[layerid];
    if (layer) {
      map?.removeLayer(layer);
      delete olLayers[layerid];
    }
  },

  getLayer: (layerid) => {
    return olLayers[layerid] || null;
  },

  getAllLayers: () => {
    return { ...olLayers };
  },
};

export default LayerManager;

// import { useRef } from 'react';

// // Custom hook to manage OpenLayers layers
// const LayerManager = () => {
//   const olLayersRef = useRef({}); // Store layers by layerid

//   const addLayer = (layerid, layer) => {
//     olLayersRef.current[layerid] = layer;
//   };

//   const removeLayer = (layerid) => {
//     if (olLayersRef.current[layerid]) {
//       delete olLayersRef.current[layerid];
//     }
//   };

//   const getLayer = (layerid) => {
//     return olLayersRef.current[layerid];
//   };

//   return {
//     olLayersRef,
//     addLayer,
//     removeLayer,
//     getLayer,
//   };
// };

// export default LayerManager;
