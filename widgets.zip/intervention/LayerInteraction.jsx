import { useEffect } from 'react';

/**
 * Hook to handle hover and click interactions on an OpenLayers vector layer.
 *
 * @param {Object} options
 * @param {ol/Map} options.map - The OpenLayers Map instance.
 * @param {string} options.layerId - A unique string identifying the target layer.
 * @param {Function} options.getLayer - A function that returns the OpenLayers Layer object.
 * @param {Function} [options.onHover] - A callback function(feature, coordinate) for pointer hover.
 * @param {Function} [options.onClick] - A callback function(feature, coordinate) for click.
 * @param {boolean} options.active - Whether the interaction should be active.
 */
export default function useLayerInteraction({
  map,
  layerId,
  getLayer,
  onHover,
  onClick,
  active,
}) {
  useEffect(() => {
    if (!map || !active) return;

    const handlePointerMove = (evt) => {
      if (!onHover) return;
      const layer = getLayer();
      if (!layer) return;

      let featureFound = false;
      map.forEachFeatureAtPixel(evt.pixel, (feature, layerCandidate) => {
        if (layerCandidate === layer) {
          featureFound = true;
          if (onHover) onHover(feature, evt.coordinate);
        }
      });
      
      const targetEl = map.getTargetElement();
      if (targetEl) {
        targetEl.style.cursor = featureFound ? 'pointer' : '';
      }
      
      if (!featureFound && onHover) {
        onHover(null, evt.coordinate); // clear hover
      }      
    };

    const handleClick = (evt) => {
      if (!onClick) return;
      const layer = getLayer();
      if (!layer) return;

      map.forEachFeatureAtPixel(evt.pixel, (feature, layerCandidate) => {
        if (layerCandidate === layer) {
          onClick(feature, evt.coordinate);
        }
      });
    };

    map.on('pointermove', handlePointerMove);
    map.on('click', handleClick);

    return () => {
      map.un('pointermove', handlePointerMove);
      map.un('click', handleClick);
    };
  }, [map, getLayer, onHover, onClick, active, layerId]);
}
