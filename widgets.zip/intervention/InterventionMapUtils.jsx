// utils/mapUtils.js
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import Utils from "../Utils"
import { Style, Fill, Stroke } from 'ol/style';
import { saveAs } from 'file-saver';
import GeoJSON from 'ol/format/GeoJSON';
import LayerManager from "./LayerManager"; 
import { LAYER_KEYS } from "./LayerConfig";


const { addLayer, removeLayer, getLayer } = LayerManager;

const InterventionMapUtils = {

  async loadBoundaryLayer(map, layerid='boundary', url) {

    await InterventionMapUtils.fetchData({
      url,
      method: 'GET',
      callback: (features) => {
        // Remove existing layers that match the layerid
        const existingLayer = getLayer(layerid);
        if (existingLayer) {
          removeLayer(layerid, map); // Remove from olLayersRef too
        }

        const vectorLayer = new VectorLayer({
          source: new VectorSource({
            features: new GeoJSON().readFeatures(
              { type: 'FeatureCollection', features },
              { featureProjection: 'EPSG:3857' }
            ),
          }),
          style: InterventionMapUtils.boundaryLayerStyleFunction,
        });

        vectorLayer.set(layerid, true);
        addLayer(layerid, vectorLayer, map);
      }
    });
  },

  /** -------------------------------------------------------------- */
  async loadDistrictLayer(map, config, done) {     
    const layerParamBuilders = {
      "district": ({ date, horizon, p_threshold, t_threshold, method }) => ({
        intervention_date: date,
        forecast_horizon: horizon,
        p_threshold,
        t_threshold,
        method,
      }),
    };
    
    const url = config.url;
    const layerid = config.layerid;    
    const params = layerParamBuilders[layerid]?.(config);
    
    if (config.boundary === true) {
      await InterventionMapUtils.loadBoundaryLayer(map, "district_boundary", config.boundary_url);
    } else {
        removeLayer("district_boundary", map); // Remove from olLayersRef too
    }

    await InterventionMapUtils.fetchData({
      url,
      method: 'POST',
      params,
      callback: (features) => {

        // Remove existing layers that match the layerid
        const existingLayer = getLayer(layerid);
        if (existingLayer) {
          removeLayer(layerid, map); // Remove from olLayersRef too
        }

        const vectorLayer = new VectorLayer({
          source: new VectorSource({
            features: new GeoJSON().readFeatures(
              { type: 'FeatureCollection', features },
              { featureProjection: 'EPSG:3857' }
            ),
          }),
          style: InterventionMapUtils.districtStyleFunction,
        });

        vectorLayer.set(layerid, true);
        addLayer(layerid, vectorLayer, map);
      }
    });
    done(true);    
  },


  /** -------------------------------------------------------------- */
  async loadCommuneLayer(map, config, done) {      
    const layerParamBuilders = {
      "commune": ({ start_year, end_year, month, threshold }) => ({
        start_year, end_year, month, threshold,
      }),
    };
    
    const url = config.url;
    const layerid = config.layerid;
    const params = layerParamBuilders[layerid]?.(config);
    
    if (config.boundary === true) {
      await InterventionMapUtils.loadBoundaryLayer(map, "commune_boundary", config.boundary_url);
    } else {
        removeLayer("commune_boundary", map); // Remove from olLayersRef too
    }

    // const { addLayer, removeLayer, getLayer } = LayerManager;

    const districtLayer = getLayer(LAYER_KEYS.DISTRICT); // Get district layer
    if (districtLayer && districtLayer.getSource) {
      const features = districtLayer.getSource().getFeatures();
      const fcodes = features
        .map(feature => feature.get('fcode'))
        .filter(fcode => fcode !== undefined);

      params['fcodes'] = fcodes;
    } else {
      console.warn('District layer not found or has no features');
    }
      
    await InterventionMapUtils.fetchData({
      url,
      method: 'POST',
      params,
      callback: (features) => {

        // Remove existing layers that match the layerid
        const existingLayer = getLayer(layerid);
        if (existingLayer) {
          removeLayer(layerid, map); // Remove from olLayersRef too
        }

        const vectorLayer = new VectorLayer({
          source: new VectorSource({
            features: new GeoJSON().readFeatures(
              { type: 'FeatureCollection', features },
              { featureProjection: 'EPSG:3857' }
            ),
          }),
          style: InterventionMapUtils.communeStyleFunction,
        });

        vectorLayer.set(layerid, true);
        addLayer(layerid, vectorLayer, map);
      }
    });
    done(true);    
  },

  /** -------------------------------------------------------------- */  
  boundaryLayerStyleFunction(feature) {
    feature.get("fcode"); //update to show custom feature styling
    return new Style({
      fill: new Fill({ color: 'rgba(255, 255, 255, 0.3)' }),
      stroke: new Stroke({ color: '#333', width: 0.1 }),
    });
  },
  
  districtStyleFunction(feature) {
    const rawValue = feature.get('pred_case_mean');
    const cases = typeof rawValue === 'number' ? Math.round(rawValue) : 0;

    return new Style({
      fill: new Fill({ color: InterventionMapUtils.getColorByCases(cases) }),
      stroke: new Stroke({ color: '#333', width: 1 }),
    });
  },

  communeStyleFunction(feature) {
    const cases = feature.get('cases') || 0;
    return new Style({
      fill: new Fill({ color: InterventionMapUtils.getColorByCases(cases) }),
      stroke: new Stroke({ color: '#333', width: 1 }),
    });
  },

  getColorByCases(cases) {
    if (cases <= 20) return 'rgba(0, 128, 0, 0.5)';
    if (cases <= 50) return 'rgba(255, 255, 0, 0.5)';
    if (cases <= 70) return 'rgba(255, 165, 0, 0.5)';
    return 'rgba(255, 0, 0, 0.6)';
  },

  /** -------------------------------------------------------------- */  

  downloadLayerData(map, layerid, filename = "mapdata.csv") {
    const vectorLayer = map.getLayers().getArray().find(layer => layer.get(layerid));
    const features = vectorLayer?.getSource()?.getFeatures();

    if (!features || features.length === 0) {
      alert("No features to download.");
      return;
    }

    const allKeys = new Set();
    features.forEach(f => {
      const props = f.getProperties();
      for (const k in props) {
        if (k !== 'geometry') allKeys.add(k);
      }
    });

    const headers = Array.from(allKeys);
    const rows = features.map(f => {
      const props = f.getProperties();
      return headers.map(h => JSON.stringify(props[h] ?? "")).join(",");
    });

    const csvContent = `${headers.join(",")}\n${rows.join("\n")}`;
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, filename);
  },

  handleDistrictHover(feature) {
    if (feature) {
      //console.log("Hovered District", feature.getProperties());
    }
  },

  handleDistrictClick(feature, map) { 
    if (!map || !feature) return;
    const geometry = feature.getGeometry();
    if (geometry) {
      const extent = geometry.getExtent();
      map.getView().fit(extent, {
        padding: [50, 50, 50, 50],
        duration: 500,
        maxZoom: 16,
      });
    }
  },

  handleCommuneHover(feature) {
    if (feature) {
      return;
      //console.log("Hovered Commune", feature.getProperties());
    } 
  },

  handleCommuneClick(feature, map) {
    if (!map || !feature) return;
    const geometry = feature.getGeometry();
    if (geometry) {
      const extent = geometry.getExtent();
      map.getView().fit(extent, {
        padding: [50, 50, 50, 50],
        duration: 500,
        maxZoom: 16,
      });
    }
  },

  getDistrictTooltip(feature) {
    const name = feature.get('address') || 'Unknown';
    const rawValue = feature.get('pred_case_mean');
    const cases = typeof rawValue === 'number' ? Math.round(rawValue) : 'N/A';

    return `
      <div style="font-family: sans-serif; padding: 4px 8px;">
        <div style="font-weight: bold; font-size: 14px; margin-bottom: 2px;">${name}</div>
        <div style="font-size: 13px; color: #555;">Total: <span style="font-weight: bold; color: #c00;">${cases} cases predicted</span></div>
      </div>
    `;
  },

  getCommuneTooltip(feature) {
    const name = feature.get('name') || 'Unknown';
    const cases = feature.get('cases') ?? 'N/A';
  
    return `
      <div style="font-family: sans-serif; padding: 4px 8px;">
        <div style="font-weight: bold; font-size: 14px; margin-bottom: 2px;">${name}</div>
        <div style="font-size: 13px; color: #555;">Total: <span style="font-weight: bold; color: #c00;">${cases} cases</span></div>
      </div>
    `;
  },
  
  /** ------------------------------------------------------------------ */

  async fetchData({ url, method = 'GET', params = null, callback }) {
    try {
      const token = Utils.getValidToken();
      if (!token) {
        alert('Please login...');
        //window.location.href = '/login';
        return null;
      }

      let fullUrl = url;
      const options = {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      };

      if (method === 'GET' && params) {
        const queryString = new URLSearchParams(params).toString();
        if (queryString.trim() !== '') fullUrl += `?${queryString}`;
      } else if (params) {
        options.body = JSON.stringify(params);
      }

      const response = await fetch(fullUrl, options);

      if (!response.ok) {
        const errorDetail = await response.json();
        throw new Error(`Error ${response.status}: ${response.statusText} - ${JSON.stringify(errorDetail)}`);
      }

      const data = await response.json();
      if (callback) callback(data);
      return data;

    } catch (error) {
      console.error('API call failed:', error);
      return null;
    }
  },

};

export default InterventionMapUtils;
