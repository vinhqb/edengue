import React, { useEffect, useRef, useState, useCallback  } from "react";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import { fromLonLat } from "ol/proj";
import "ol/ol.css";
import { FaCog, FaTimes, FaDownload, FaSyncAlt } from "react-icons/fa";
import IncidenceMapUtils from "./IncidenceMapUtils";
import useLayerInteraction from "./LayerInteraction";
import styles from "./styles.module.css"
import IncidenceAnalyzer from "./IncidenceAnalyzer"
import IncidenceClusterAnalyzer from "./IncidenceClusterAnalyzer"
import AnimatedHeatmap from "./IncidenceAnimatedHeatmapPlain";
import Utils from "../Utils";

// add map legend for each layer
const clusterMapLegend = [
  { color: '#339966', label: "0–20 cases" },
  { color: '#cc9900', label: "21–50 cases" },
  { color: '#ff6600', label: "51–70 cases" },
  { color: '#cc0000', label: "71+ cases" },
  // { color: "green", label: "low risk" },
  // { color: "yellow", label: "medium risk" },
  // { color: "red", label: "high risk" },
]
 
const incidenceMapLegend = [
  { color: '#339966', label: "0–20 cases" },
  { color: '#cc9900', label: "21–50 cases" },
  { color: '#ff6600', label: "51–70 cases" },
  { color: '#cc0000', label: "71+ cases" },
  // { color: "green", label: "low risk" },
  // { color: "yellow", label: "medium risk" },
  // { color: "red", label: "high risk" },
]

const heatMapLegend = [
  { color: "green", label: "low density" },
  { color: "yellow", label: "medium density" },
  { color: "red", label: "high density" },
]

const layerLegends = {
  cluster: clusterMapLegend,
  heatmap: heatMapLegend,  
  incidence: incidenceMapLegend,
};


const IncidenceMapWidget = ({ title, onRemove }) => {
    const mapRef = useRef();
    const olMapRef = useRef();
    
    const [configOpen, setConfigOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [selectedCluster, setSelectedCluster] = useState(null);
    const [selectedFeature, setSelectedFeature] = useState(null);

    const [layerConfig, setLayerConfig] = useState({
      layerid: 'incidence',
      case_url: Utils.API_BASE_URL + "/cases/select",
      fcodes: null,
      start_date: "2022-01-01",
      end_date: "2022-02-01",
      window_size: 14,
      map_type: "cluster",
      boundary: true,
      boundary_url: Utils.API_BASE_URL + "/boundary/districts",
      incidence_url: Utils.API_BASE_URL + "/cases/incidence",
      visible: false,
    });

    const [draftConfig, setDraftConfig] = useState(layerConfig);
    //const [activeMap, setActiveMap] = useState(config.map_type);

    const applyLayerConfig = useCallback(() => {
        const layerLoader = IncidenceMapUtils.loadIncidenceData;
        setLayerConfig(draftConfig);
        if (olMapRef.current && typeof layerLoader === "function") {
          setLoading(true);

          // Timeout fallback in case data load hangs
          const timeoutId = setTimeout(() => {
            setLoading(false);
            alert(`Loading timeout for layer "${layerConfig.layerid}"`);
            console.warn(`Loading timeout for layer "${layerConfig.layerid}"`);
          }, 360000); // 120 seconds

          layerLoader(olMapRef.current, draftConfig, (success = true) => {
            clearTimeout(timeoutId);
            setLoading(!success); // Assume false disables loading if fetch fails
          });
        }
      }, [layerConfig, draftConfig]);

      
    useEffect(() => {
      const mapContainer = mapRef.current;
      olMapRef.current = new Map({
        target: mapContainer,
        layers: [new TileLayer({ source: new OSM() })],
        view: new View({
          center: fromLonLat([106.0, 10.0]),
          zoom: 7,
          projection: "EPSG:3857",
        }),
      });
  
      const resizeObserver = new ResizeObserver(() => {
        if (olMapRef.current) olMapRef.current.updateSize();
      });
  
      if (mapContainer) resizeObserver.observe(mapContainer);
  
      return () => {
        if (mapContainer) resizeObserver.unobserve(mapContainer);
        if (olMapRef.current) olMapRef.current.setTarget(null);
      };
    }, []);
  
    //Prevent effect from firing on mount
    const didMountRef = useRef(false);
    useEffect(() => {
      if (didMountRef.current) {
        if (layerConfig.visible) {
            applyLayerConfig();
          }
      } else {
        didMountRef.current = true;
      }
    }, [layerConfig, applyLayerConfig]);
      

    const handleConfigChange = (e) => {
      const { name, type, value, checked } = e.target;
      const newValue = type === 'checkbox' ? checked : value;
      
      const updatedConfig = {
        ...draftConfig,
        [name]: newValue,
      };
    
      setDraftConfig(updatedConfig);
    
      if (olMapRef.current && (name === 'map_type')||(name == 'boundary')) {
        IncidenceMapUtils.setLayersVisibility(updatedConfig, olMapRef.current);
      }
    };
    
    //Add interactions
    useLayerInteraction({
      map: olMapRef.current,
      layerid: 'incidence', //enable interaction with cluster
      onClick:  (feature, map) => IncidenceMapUtils.handleIncidenceClick(feature, map, setSelectedFeature),
      active: true,
    });

    //Add interactions
    useLayerInteraction({
      map: olMapRef.current,
      layerid: 'cluster', //enable interaction with cluster
      onClick:  (feature, map) => IncidenceMapUtils.handleClusterClick(feature, map, setSelectedCluster),
      active: true,
    });

    return (
      <>
        <div className="widget-header">
          <button onClick={() => setConfigOpen(!configOpen)} onTouchStart={() => setConfigOpen(!configOpen)} className="config-button" title="Configure">
            <FaCog />
          </button>
          <div className="widget-title">{title}</div>
          <button onClick={onRemove} onTouchStart={onRemove} className="remove-button" title="Remove">
            <FaTimes />
          </button>
        </div>
  
        <div className="widget-content" style={{ width: "100%", height: "100%", boxSizing: "border-box" }}>
          {configOpen && (
            <div
              style={{
                marginBottom: "10px",
                background: "#f5f5f5",
                padding: "10px",
                borderRadius: "5px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
                <div style={{ display: "flex", flexDirection: "column" }}>
                  <label>Start Date:</label>
                  <input
                    type="date"
                    name="start_date"
                    value={draftConfig.start_date}
                    onChange={handleConfigChange}
                    disabled={loading}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "column" }}>
                  <label>End Date:</label>
                  <input
                    type="date"
                    name="end_date"
                    value={draftConfig.end_date}
                    onChange={handleConfigChange}
                    disabled={loading}
                  />
                </div>
                <div style={{ display: "flex", flexDirection: "column" }}>
                  <label>Map Type:</label>
                  <select
                    name="map_type"
                    value={draftConfig.map_type}
                    onChange={handleConfigChange}
                    disabled={loading}
                    >
                    <option value="cluster">Cluster</option>
                    <option value="heatmap">Heatmap</option>
                    <option value="incidence">Incidence</option>
                   </select>
                </div>

                <div style={{ display: "flex", flexDirection: "column" }}>
                  <label>Boundary:</label>
                  <input 
                    type="checkbox"
                    name="boundary"
                    checked={draftConfig.boundary} 
                    onChange={handleConfigChange}
                    disabled={loading}
                  />
                </div>
                <button
                    onClick={applyLayerConfig}
                    disabled={loading}
                    className="p-2 rounded-full hover:bg-gray-200 transition"
                    title="Refresh Data"
                    >
                    <FaSyncAlt size={16} />
                </button>                
                <button
                  onClick={() => IncidenceMapUtils.downloadLayerData(olMapRef.current, layerConfig.layerid, "danh_sach_ca_benh.csv")}
                  className="p-2 rounded-full hover:bg-gray-200 transition"
                  title="Download CSV"
                  disabled={loading}
                >
                  <FaDownload size={16} />
                </button>
              </div>
            </div>
          )}
          

          {draftConfig.map_type === 'heatmap' && (
            <AnimatedHeatmap
              heatmapLayer={olMapRef.current
                ?.getLayers()
                .getArray()
                .find(l => l.get(draftConfig.layerid) === 'heatmap')}
              config={draftConfig}
              isVisible
            />
          )}


          <div
            ref={mapRef}
            style={{
              position: "relative",
              width: "100%",
              height: configOpen ? "calc(100% - 75px)" : "100%",
              backgroundColor: "#ddd",
              boxSizing: "border-box",
            }}
          >
            {loading && (
              <div
                style={{
                  position: "absolute",
                  top: 0, left: 0, right: 0, bottom: 0,
                  background: "rgba(255,255,255,0.7)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  zIndex: 1000,
                  fontWeight: "bold",
                }}
              >
                Loading data...
              </div>
            )}
          </div>
        </div>
        <div className={styles["map-legend"]}>
          {layerLegends[draftConfig.map_type]?.map(({ color, label }, idx) => (
              <div key={idx}>
                <span className={styles["legend-color"]} style={{ backgroundColor: color }}></span> {label}
              </div>
          ))}        
        </div>  

        {selectedCluster && (
        <IncidenceClusterAnalyzer
          clusterFeature={selectedCluster.feature}
          map={selectedCluster.map}
        />
        )}

        {selectedFeature && (
        <IncidenceAnalyzer
          feature={selectedFeature.feature}
          map={selectedFeature.map}
        />
        )}

      </>
    );
  };
  
  export default IncidenceMapWidget;
  