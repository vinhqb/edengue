import React, { useState, useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';  // Import Chart.js

const IncidenceClusterAnalyzer = ({ clusterFeature, map }) => {
  const [popupStyle, setPopupStyle] = useState(null);
  const [chartData, setChartData] = useState(null);
  const chartCanvasRef1 = useRef(null);
  const chartCanvasRef2 = useRef(null);
  const chartInstance1Ref = useRef(null);
  const chartInstance2Ref = useRef(null);

  const [dragging, setDragging] = useState(false);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const popupRef = useRef(null);

  function getYearWeek(date) {
    const targetDate = new Date(date.getTime());
    targetDate.setDate(targetDate.getDate() + (4 - (targetDate.getDay() || 7)));
    const firstDayOfYear = new Date(targetDate.getFullYear(), 0, 1);
    const weekNumber = Math.ceil((((targetDate - firstDayOfYear) / 86400000) + 1) / 7);
    return `${targetDate.getFullYear()}-W${String(weekNumber).padStart(2, '0')}`;
  }

  useEffect(() => {
    if (!clusterFeature || !map) return;

    const features = clusterFeature.get('features');
    const weekCounts = {};
    const weekYearCounts = {};

    features.forEach((feature) => {
      const dateDetected = feature.get('date_detected');
      if (!dateDetected) return;

      const date = new Date(dateDetected);
      const yearWeek = getYearWeek(date);
      weekCounts[yearWeek] = (weekCounts[yearWeek] || 0) + 1;

      const year = date.getFullYear();
      const week = Math.ceil((date.getTime() - new Date(year, 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000));
      weekYearCounts[week] ??= {};
      weekYearCounts[week][year] = (weekYearCounts[week][year] || 0) + 1;
    });

    const sortedWeeks = Object.keys(weekCounts).sort();
    const data = sortedWeeks.map((week) => weekCounts[week]);
    const labels = sortedWeeks;

    const weeks = Object.keys(weekYearCounts).sort((a, b) => a - b);
    const years = [...new Set(features.map(f => new Date(f.get('date_detected')).getFullYear()))].sort();
    const datasets = years.map((year) => ({
      label: year,
      data: weeks.map((week) => weekYearCounts[week]?.[year] || 0),
      backgroundColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.5)`,
    }));

    setChartData({ labels, data, weeks, datasets });

    const clusterCoord = clusterFeature.getGeometry().getCoordinates();
    const pixel = map.getPixelFromCoordinate(clusterCoord);
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const popupWidth = 400;
    const popupHeight = 350;

    let left = Math.min(pixel[0], viewportWidth - popupWidth - 20);
    let top = Math.min(pixel[1], viewportHeight - popupHeight - 20);

    setPopupStyle({
      left: `${Math.max(left, 20)}px`,
      top: `${Math.max(top, 20)}px`,
    });
  }, [clusterFeature, map]); // Trigger when clusterFeature or map change

  const closePopup = () => {
    setPopupStyle(null); // Hide the popup
  };

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (!dragging || !popupRef.current) return;

      const newLeft = e.clientX - offset.x;
      const newTop = e.clientY - offset.y;

      popupRef.current.style.left = `${newLeft}px`;
      popupRef.current.style.top = `${newTop}px`;
    };

    const handleMouseUp = () => {
      setDragging(false);
    };

    // Prevent text selection while dragging
    if (dragging) {
      document.body.style.userSelect = 'none';
    } else {
      document.body.style.userSelect = 'auto';
    }

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging, offset]);

  const handleMouseDown = (e) => {
    const titleHeight = document.getElementById("popup-header")?.offsetHeight || 0;
    const offsetX = e.clientX - popupRef.current.offsetLeft;
    const offsetY = e.clientY - popupRef.current.offsetTop + titleHeight; // adjust here
  
    setOffset({ x: offsetX, y: offsetY });
    setDragging(true);
    // Prevent default text selection during drag
    e.preventDefault();

  };  
//   const handleMouseDown = (e) => {
//     const rect = popupRef.current.getBoundingClientRect();
//     setOffset({
//       x: e.clientX - rect.left,
//       y: e.clientY - rect.top,
//     });
//     setDragging(true);
//     // Prevent default text selection during drag
//     e.preventDefault();
//   };

  useEffect(() => {
    if (chartData) {
        const ctx1 = chartCanvasRef1.current;
        const ctx2 = chartCanvasRef2.current;

        // Clean up existing charts
        if (chartInstance1Ref.current) {
        chartInstance1Ref.current.destroy();
        }
        if (chartInstance2Ref.current) {
        chartInstance2Ref.current.destroy();
        }

        // Chart 1 - Dengue Cases per Week
        chartInstance1Ref.current = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: chartData.labels,
            datasets: [
            {
                label: 'Cases per Week',
                data: chartData.data,
                backgroundColor: 'rgba(0, 123, 255, 0.5)',
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 1,
            },
            ],
        },
        options: {
            maintainAspectRatio: false,
            scales: {
            y: { beginAtZero: true },
            },
        },
        });

        // Chart 2 - Accumulated Dengue Cases
        const accumulatedData = chartData.data.reduce((acc, value, index) => {
        acc.push(value + (acc[index - 1] || 0));
        return acc;
        }, []);

        chartInstance2Ref.current = new Chart(ctx2, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [
            {
                label: 'Accumulated Cases',
                data: accumulatedData,
                backgroundColor: 'rgba(0, 123, 255, 0.5)',
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 2,
                fill: false,
            },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
            legend: { position: 'top' },
            },
            scales: {
            x: { title: { display: true, text: 'Weeks' } },
            y: { title: { display: true, text: 'Accumulated Cases' }, beginAtZero: true },
            },
        },
        });
    }

    // Cleanup on unmount
    return () => {
        if (chartInstance1Ref.current) chartInstance1Ref.current.destroy();
        if (chartInstance2Ref.current) chartInstance2Ref.current.destroy();
    };
  }, [chartData]);


  if (!chartData) return null; // Do not render if no chartData

  return (
    <div>
      {popupStyle && (
        <div
          ref={popupRef}
          id="chart-popup"
          style={{
            position: 'absolute',
            background: 'white',
            border: '1px solid #ccc',
            padding: '10px',
            borderRadius: '8px',
            boxShadow: '0 4px 8px rgba(0,0,0,0.2)',
            zIndex: 1000,
            resize: 'both',
            overflow: 'hidden',
            width: '400px',
            height: '350px',
            ...popupStyle,
          }}
        >
          <div
            id="popup-header"
            style={{
              width: '100%',
              cursor: 'grab',
              background: '#f0f0f0',
              padding: '5px 10px',
              borderBottom: '1px solid #ccc',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              boxSizing: 'border-box',
              userSelect: dragging ? 'none' : 'auto', // Prevent text selection while dragging
            }}
            onMouseDown={handleMouseDown}
          >
            <span style={{ fontWeight: 'bold' }}>Dengue Weekly Data</span>
            <button
              id="close-popup"
              onClick={closePopup}
              style={{
                background: '#888888',
                border: 'none',
                fontSize: '14px',
                cursor: 'pointer',
                width: '24px',
                height: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                lineHeight: '1',
                margin: '0',
                padding: '0',
              }}
            >
              &times;
            </button>
          </div>
          <div
            id="chart-container"
            style={{
              display: 'flex',
              flexDirection: 'column',
              width: '100%',
              height: 'calc(100% - 50px)',
              boxSizing: 'border-box',
              gap: '10px',
            }}
          >
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <canvas ref={chartCanvasRef1} style={{ width: '100%', height: '100%' }}></canvas>
            </div>
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <canvas ref={chartCanvasRef2} style={{ width: '100%', height: '100%' }}></canvas>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IncidenceClusterAnalyzer;


// import React, { useState, useEffect, useRef } from 'react';
// import Chart from 'chart.js/auto';

// const IncidenceClusterAnalyzer = ({ clusterFeature, map }) => {
//   const [popupStyle, setPopupStyle] = useState(null);
//   const [chartData, setChartData] = useState(null);
//   const chartCanvasRef1 = useRef(null);
//   const chartCanvasRef2 = useRef(null);

//   function getYearWeek(date) {
//     const targetDate = new Date(date.getTime());
//     targetDate.setDate(targetDate.getDate() + (4 - (targetDate.getDay() || 7)));
//     const firstDayOfYear = new Date(targetDate.getFullYear(), 0, 1);
//     const weekNumber = Math.ceil((((targetDate - firstDayOfYear) / 86400000) + 1) / 7);
//     return `${targetDate.getFullYear()}-W${String(weekNumber).padStart(2, '0')}`;
//   }

//   useEffect(() => {
//     if (!clusterFeature || !map) return;

//     const features = clusterFeature.get('features');
//     const weekCounts = {};
//     const weekYearCounts = {};

//     features.forEach((feature) => {
//       const dateDetected = feature.get('date_detected');
//       if (!dateDetected) return;

//       const date = new Date(dateDetected);
//       const yearWeek = getYearWeek(date);
//       weekCounts[yearWeek] = (weekCounts[yearWeek] || 0) + 1;

//       const year = date.getFullYear();
//       const week = Math.ceil((date - new Date(year, 0, 1)) / (7 * 24 * 60 * 60 * 1000));
//       weekYearCounts[week] ??= {};
//       weekYearCounts[week][year] = (weekYearCounts[week][year] || 0) + 1;
//     });

//     const sortedYearWeeks = Object.keys(weekCounts).sort();
//     const chart1Labels = sortedYearWeeks;
//     const chart1Data = sortedYearWeeks.map((week) => weekCounts[week]);

//     const weeks = Object.keys(weekYearCounts).sort((a, b) => a - b);
//     const years = [...new Set(features.map(f => new Date(f.get('date_detected')).getFullYear()))].sort();

//     const chart2Datasets = years.map((year) => {
//       let cumulative = 0;
//       const data = weeks.map((week) => {
//         const value = weekYearCounts[week]?.[year] || 0;
//         cumulative += value;
//         return cumulative;
//       });
//       return {
//         label: `${year}`,
//         data,
//         fill: false,
//         borderColor: `hsl(${Math.floor(Math.random() * 360)}, 70%, 50%)`,
//         tension: 0.2,
//       };
//     });

//     setChartData({
//       chart1: { labels: chart1Labels, data: chart1Data },
//       chart2: { weeks: weeks.map(w => `Week ${w}`), datasets: chart2Datasets },
//     });

//     const clusterCoord = clusterFeature.getGeometry().getCoordinates();
//     const pixel = map.getPixelFromCoordinate(clusterCoord);
//     const viewportWidth = window.innerWidth;
//     const viewportHeight = window.innerHeight;
//     const popupWidth = 400;
//     const popupHeight = 350;

//     let left = Math.min(pixel[0], viewportWidth - popupWidth - 20);
//     let top = Math.min(pixel[1], viewportHeight - popupHeight - 20);

//     setPopupStyle({
//       left: `${Math.max(left, 20)}px`,
//       top: `${Math.max(top, 20)}px`,
//     });
//   }, [clusterFeature, map]);

//   const closePopup = () => setPopupStyle(null);

//   useEffect(() => {
//     if (!chartData) return;

//     const ctx1 = chartCanvasRef1.current;
//     const ctx2 = chartCanvasRef2.current;
//     Chart.getChart(ctx1)?.destroy();
//     Chart.getChart(ctx2)?.destroy();

//     // Chart 1: Weekly case counts
//     new Chart(ctx1, {
//       type: 'bar',
//       data: {
//         labels: chartData.chart1.labels,
//         datasets: [{
//           label: 'Cases per Week',
//           data: chartData.chart1.data,
//           backgroundColor: 'rgba(0, 123, 255, 0.5)',
//           borderColor: 'rgba(0, 123, 255, 1)',
//           borderWidth: 1,
//         }],
//       },
//       options: {
//         maintainAspectRatio: false,
//         scales: {
//           y: { beginAtZero: true },
//         },
//       },
//     });

//     // Chart 2: Cumulative cases per year
//     new Chart(ctx2, {
//       type: 'line',
//       data: {
//         labels: chartData.chart2.weeks,
//         datasets: chartData.chart2.datasets,
//       },
//       options: {
//         responsive: true,
//         maintainAspectRatio: false,
//         plugins: {
//           legend: { position: 'top' },
//           tooltip: {
//             callbacks: {
//               label: (ctx) => `${ctx.dataset.label}: ${ctx.raw}`,
//             },
//           },
//         },
//         scales: {
//           x: {
//             title: { display: true, text: 'Weeks' },
//           },
//           y: {
//             title: { display: true, text: 'Cumulative Cases' },
//             beginAtZero: true,
//           },
//         },
//       },
//     });
//   }, [chartData]);

//   if (!chartData) return null;

//   return (
//     <div>
//       {popupStyle && (
//         <div
//           style={{
//             position: 'absolute',
//             background: 'white',
//             border: '1px solid #ccc',
//             padding: '10px',
//             borderRadius: '8px',
//             boxShadow: '0 4px 8px rgba(0,0,0,0.2)',
//             zIndex: 1000,
//             resize: 'both',
//             overflow: 'hidden',
//             width: '400px',
//             height: '350px',
//             ...popupStyle,
//           }}
//         >
//           <div
//             style={{
//               width: '100%',
//               cursor: 'grab',
//               background: '#f0f0f0',
//               padding: '5px 10px',
//               borderBottom: '1px solid #ccc',
//               display: 'flex',
//               justifyContent: 'space-between',
//               boxSizing: 'border-box',
//             }}
//           >
//             <span style={{ fontWeight: 'bold' }}>Dengue Weekly Data</span>
//             <button onClick={closePopup} style={{
//               background: '#888',
//               border: 'none',
//               fontSize: '14px',
//               cursor: 'pointer',
//               width: '24px',
//               height: '24px',
//               display: 'flex',
//               alignItems: 'center',
//               justifyContent: 'center',
//               lineHeight: '1',
//             }}>&times;</button>
//           </div>
//           <div
//             style={{
//               display: 'flex',
//               flexDirection: 'column',
//               width: '100%',
//               height: 'calc(100% - 50px)',
//               boxSizing: 'border-box',
//               gap: '10px',
//             }}
//           >
//             <div style={{ flex: 1 }}>
//               <canvas ref={chartCanvasRef1} style={{ width: '100%', height: '100%' }} />
//             </div>
//             <div style={{ flex: 1 }}>
//               <canvas ref={chartCanvasRef2} style={{ width: '100%', height: '100%' }} />
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default IncidenceClusterAnalyzer;

