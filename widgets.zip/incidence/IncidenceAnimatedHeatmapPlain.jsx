import React, { useState, useRef, useEffect } from "react";
import styles from "./styles.module.css";

const AnimatedHeatmap = ({ heatmapLayer, config, isVisible }) => {
  const [intervalDays, setIntervalDays] = useState(1);
  const [sliderValue, setSliderValue] = useState(
    new Date(config.start_date).getTime()
  );
  const [currentDate, setCurrentDate] = useState(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [hasStarted, setHasStarted] = useState(false); // NEW state

  const animationInterval = useRef(null);
  const heatmapRef = useRef(null);
  const pausedRef = useRef(false);
  const originalFeaturesRef = useRef([]);


  useEffect(() => {
    // Store original features on initial mount
    if (heatmapLayer && heatmapLayer.getSource) {
      const original = heatmapLayer.getSource().getFeatures();
      originalFeaturesRef.current = [...original];
    }
  }, [heatmapLayer]);

  const dragStart = (e) => {
    const offsetX = e.clientX - heatmapRef.current.offsetLeft;
    const offsetY = e.clientY - heatmapRef.current.offsetTop;

    const dragMove = (moveEvent) => {
      heatmapRef.current.style.left = `${moveEvent.clientX - offsetX}px`;
      heatmapRef.current.style.top = `${moveEvent.clientY - offsetY}px`;
    };

    const dragEnd = () => {
      document.removeEventListener("mousemove", dragMove);
      document.removeEventListener("mouseup", dragEnd);
    };

    document.addEventListener("mousemove", dragMove);
    document.addEventListener("mouseup", dragEnd);
  };

  const toggleCollapse = () => setIsCollapsed(!isCollapsed);

  const parseDate = (str) => {
    const date = new Date(str);
    return isNaN(date.getTime()) ? null : date;
  };

  const updateHeatmapFeatures = (viewDate) => {
    const source = heatmapLayer.getSource();
    const startWindow = new Date(viewDate);
    startWindow.setDate(startWindow.getDate() - config.window_size);

    const filtered = originalFeaturesRef.current.filter((feature) => {
      const dateStr = feature.get("date_detected");
      if (!dateStr) return false;
      const featureDate = new Date(dateStr);
      return featureDate > startWindow && featureDate <= viewDate;
    });

    source.clear();
    source.addFeatures(filtered);
  };
  
  const stopAnimation = () => {
    clearInterval(animationInterval.current);
    animationInterval.current = null;
    setCurrentDate(null);
    setIsPaused(false);
    pausedRef.current = false;
    setIsAnimating(false);
    setHasStarted(false); // Re-enable Start button

    //reset the slider
    const start = parseDate(config.start_date);
    let viewDate = new Date(start);
    setCurrentDate(viewDate);
    setSliderValue(viewDate.getTime());

    // Restore original features
    if (heatmapLayer) {
      const source = heatmapLayer.getSource();
      source.clear();
      source.addFeatures(originalFeaturesRef.current);
    }
  };

  const startAnimation = () => {
    const start = parseDate(config.start_date);
    const end = parseDate(config.end_date);
    if (!start || !end || start >= end) {
      alert("Invalid date range.");
      return;
    }

    let viewDate = currentDate || new Date(start);
    setCurrentDate(viewDate);
    setSliderValue(viewDate.getTime());
    setIsAnimating(true);
    setIsPaused(false);
    pausedRef.current = false;
    setHasStarted(true); // Disable Start button

    animationInterval.current = setInterval(() => {
        if (pausedRef.current) return;
      
        if (viewDate > end) {
          stopAnimation();
          return;
        }
      
        updateHeatmapFeatures(viewDate);
        setSliderValue(viewDate.getTime());
      
        viewDate.setDate(viewDate.getDate() + intervalDays);
        setCurrentDate(new Date(viewDate));
      }, 500);
    };

    const pauseAnimation = () => {
        setIsPaused(true);
        pausedRef.current = true;
      };
      
      const resumeAnimation = () => {
        setIsPaused(false);
        pausedRef.current = false;
      };
    
  if (!isVisible) return null;

  const startMillis = parseDate(config.start_date)?.getTime() || 0;
  const endMillis = parseDate(config.end_date)?.getTime() || 100;

  const handleSliderChange = (e) => {
    const newTime = parseInt(e.target.value);
    setSliderValue(newTime);
    const viewDate = new Date(newTime);
    updateHeatmapFeatures(viewDate);
  };

  return (
    <div
      ref={heatmapRef}
      className={styles["animated-heatmap"]}
      onMouseDown={dragStart}
    >
      <div className={styles["header"]}>
        <span>Heatmap Animation</span>
        <button onClick={toggleCollapse} className={styles["collapse-btn"]}>
          {isCollapsed ? "⭢" : "⭣"}
        </button>
      </div>

      {!isCollapsed && (
        <div className={styles["controls"]}>
          <label>Interval (days):</label>
          <input
            type="number"
            value={intervalDays}
            min={1}
            onChange={(e) => setIntervalDays(parseInt(e.target.value) || 1)}
          />

          <label>Date:</label>
          <input
            type="range"
            min={startMillis}
            max={endMillis}
            step={intervalDays * 24 * 60 * 60 * 1000}
            value={sliderValue}
            onChange={handleSliderChange}
            disabled={!isAnimating}
          />
          <div>{new Date(sliderValue).toISOString().split("T")[0]}</div>

          <div className={styles["buttons"]}>
            <button onClick={startAnimation} disabled={hasStarted}>
              Start
            </button>
            <button onClick={pauseAnimation} disabled={!isAnimating || isPaused}>
              Pause
            </button>
            <button onClick={resumeAnimation} disabled={!isAnimating || !isPaused}>
              Continue
            </button>
            <button onClick={stopAnimation}>Stop</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnimatedHeatmap;
