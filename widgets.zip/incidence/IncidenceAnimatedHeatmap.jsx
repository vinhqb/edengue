import React, { useRef, useState } from 'react';
import Slider from '@mui/material/Slider';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Draggable from 'react-draggable';
import IconButton from '@mui/material/IconButton';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';

export default function AnimatedHeatmap({ heatmapLayer, isVisible }) {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [intervalDays, setIntervalDays] = useState(1);
  const [windowDays, setWindowDays] = useState(14);
  const [sliderValue, setSliderValue] = useState(0);
  const [currentDate, setCurrentDate] = useState(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  const animationInterval = useRef(null);

  const parseDate = (str) => {
    try {
      return new Date(str);
    } catch {
      return null;
    }
  };

  const updateHeatmapFeatures = (viewDate) => {
    const source = heatmapLayer.getSource();
    const startWindow = new Date(viewDate);
    startWindow.setDate(startWindow.getDate() - windowDays);

    const allFeatures = source.getFeatures();
    const filtered = allFeatures.filter((feature) => {
      const dateStr = feature.get('date_detected');
      if (!dateStr) return false;
      const featureDate = new Date(dateStr);
      return featureDate > startWindow && featureDate <= viewDate;
    });

    source.clear();
    source.addFeatures(filtered);
  };

  const stopAnimation = () => {
    clearInterval(animationInterval.current);
    animationInterval.current = null;
    setCurrentDate(null);
    setIsPaused(false);
    setIsAnimating(false);
    setSliderValue(0);
  };

  const startAnimation = () => {
    const start = parseDate(startDate);
    const end = parseDate(endDate);
    if (!start || !end || start >= end) {
      alert('Invalid date range.');
      return;
    }

    let viewDate = currentDate || new Date(start);
    setCurrentDate(viewDate);
    setSliderValue(viewDate.getTime());
    setIsAnimating(true);
    setIsPaused(false);

    animationInterval.current = setInterval(() => {
      if (isPaused) return;

      if (viewDate > end) {
        stopAnimation();
        return;
      }

      updateHeatmapFeatures(viewDate);
      setSliderValue(viewDate.getTime());

      viewDate.setDate(viewDate.getDate() + intervalDays);
      setCurrentDate(new Date(viewDate));
    }, 500);
  };

  const pauseAnimation = () => {
    setIsPaused(true);
  };

  const resumeAnimation = () => {
    setIsPaused(false);
  };

  return isVisible ? (
    <Draggable handle=".drag-handle">
      <Box sx={{
        width: 300,
        p: 2,
        position: 'absolute',
        top: 10,
        right: 10,
        bgcolor: 'white',
        borderRadius: 2,
        boxShadow: 3,
        zIndex: 1000,
      }}>
        <Box className="drag-handle" sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'move' }}>
          <Typography variant="h6">Heatmap Animation</Typography>
          <Box>
            <IconButton size="small" onClick={() => setCollapsed(!collapsed)}>
              {collapsed ? <ExpandMoreIcon /> : <ExpandLessIcon />}
            </IconButton>
          </Box>
        </Box>

        {!collapsed && (
          <>
            <TextField
              label="Start Date"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              size="small"
              fullWidth
              margin="dense"
            />
            <TextField
              label="End Date"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              size="small"
              fullWidth
              margin="dense"
            />
            <TextField
              label="Interval (days)"
              type="number"
              value={intervalDays}
              onChange={(e) => setIntervalDays(parseInt(e.target.value))}
              size="small"
              fullWidth
              margin="dense"
            />
            <TextField
              label="Window Size (days)"
              type="number"
              value={windowDays}
              onChange={(e) => setWindowDays(parseInt(e.target.value))}
              size="small"
              fullWidth
              margin="dense"
            />
            <Slider
              value={sliderValue}
              min={parseDate(startDate)?.getTime() || 0}
              max={parseDate(endDate)?.getTime() || 100}
              onChange={(e, val) => setSliderValue(val)}
              disabled={!isAnimating}
            />
            <Typography variant="body2">
              {sliderValue ? new Date(sliderValue).toISOString().split('T')[0] : 'No date'}
            </Typography>
            <Box sx={{ mt: 1, display: 'flex', gap: 1 }}>
              <Button variant="contained" onClick={startAnimation} disabled={isAnimating && !isPaused}>Start</Button>
              <Button variant="contained" onClick={pauseAnimation} disabled={!isAnimating || isPaused}>Pause</Button>
              <Button variant="contained" onClick={resumeAnimation} disabled={!isAnimating || !isPaused}>Continue</Button>
              <Button variant="outlined" onClick={stopAnimation}>Stop</Button>
            </Box>
          </>
        )}
      </Box>
    </Draggable>
  ) : null;
}