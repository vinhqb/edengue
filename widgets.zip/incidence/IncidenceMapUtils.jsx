// utils/mapUtils.js
import VectorLayer from 'ol/layer/Vector';
import HeatmapLayer from 'ol/layer/Heatmap';
import VectorSource from 'ol/source/Vector'
import ClusterSource from 'ol/source/Cluster';
//import { createEmpty, extend } from 'ol/extent';

import Utils from "../Utils"
//import { Style, Fill, Stroke } from 'ol/style';
import Style from 'ol/style/Style';
import Text from 'ol/style/Text';
import Fill from 'ol/style/Fill';
import Stroke from 'ol/style/Stroke';
import CircleStyle from 'ol/style/Circle';

import { saveAs } from 'file-saver';
import GeoJSON from 'ol/format/GeoJSON';


const IncidenceMapUtils = {

  async loadIncidenceData(map, config, done) {

    const params = {
      fcodes: config.fcodes,
      start_date: config.start_date,
      end_date: config.end_date,
      admin_level: config.admin_level,
    };
  
    // Remove previous layers with matching config.layerid
    map.getLayers().getArray()
      .filter(l => l.get(config.layerid))
      .forEach(l => map.removeLayer(l));
  
    // --- Create sources and layers first ---
  
    // 1. Boundary layer setup
    const boundaryVectorSource = new VectorSource();
    const boundaryLayer = new VectorLayer({
      source: boundaryVectorSource,
      style: IncidenceMapUtils.boundaryLayerStyleFunction,
    });
    boundaryLayer.set(config.layerid, 'boundary');
    map.addLayer(boundaryLayer);
    boundaryLayer.setVisible(config.boundary);
  
    // 2. Incidence (heatmap/cluster/incidence) layers setup
    const caseVectorSource = new VectorSource();
  
    const heatmapLayer = new HeatmapLayer({
      source: caseVectorSource,
      blur: 10,
      radius: 5,
      weight: (feature) => feature.get('weight') || 1,
    });
  
    const clusterSource = new ClusterSource({
      distance: 40,
      source: caseVectorSource,
    });
  
    const clusterLayer = new VectorLayer({
      source: clusterSource,
      style: IncidenceMapUtils.clusterLayerStyleFunction,
    });
  
    const incidenceVectorSource = new VectorSource();
    const incidenceLayer = new VectorLayer({
      source: incidenceVectorSource,
      style: IncidenceMapUtils.incidenceLayerStyleFunction,
    });

    heatmapLayer.set(config.layerid, 'heatmap');
    clusterLayer.set(config.layerid, 'cluster');
    incidenceLayer.set(config.layerid, 'incidence');

    //enable layer interaction
    clusterLayer.set('interaction', 'cluster'); 
    incidenceLayer.set('interaction', 'incidence');
  
    map.addLayer(heatmapLayer);
    map.addLayer(clusterLayer);
    map.addLayer(incidenceLayer);

    heatmapLayer.setVisible(config.map_type === 'heatmap');
    clusterLayer.setVisible(config.map_type === 'cluster');
    incidenceLayer.setVisible(config.map_type === 'incidence');

    // --- Fetch and populate boundary data ---
    await IncidenceMapUtils.fetchData({
      url: config.boundary_url,
      method: 'GET',
      callback: (features) => {
        const boundaryFeatures = new GeoJSON().readFeatures(
          { type: 'FeatureCollection', features },
          { featureProjection: 'EPSG:3857' }
        );
        boundaryVectorSource.clear();
        boundaryVectorSource.addFeatures(boundaryFeatures);
      }
    });

    // --- Fetch and populate case data ---
    await IncidenceMapUtils.fetchData({
      url: config.case_url,
      method: 'POST',
      params: params,
      callback: (features) => {
        const caseFeatures = new GeoJSON().readFeatures(
          { type: 'FeatureCollection', features },
          { featureProjection: 'EPSG:3857' }
        );
        caseVectorSource.clear();
        caseVectorSource.addFeatures(caseFeatures);
      }
    });
    
    // --- Fetch and populate incidence data ---
    await IncidenceMapUtils.fetchData({
      url: config.incidence_url,
      method: 'POST',
      params: params,
      callback: (features) => {
        const incidenceFeatures = new GeoJSON().readFeatures(
          { type: 'FeatureCollection', features },
          { featureProjection: 'EPSG:3857' }
        );
        incidenceVectorSource.clear();
        incidenceVectorSource.addFeatures(incidenceFeatures);
      }
    });
  
    done(true);
  },
    
  incidenceLayerStyleFunction(feature) {
    const rate = feature.get('incidence');

    let color;
    if (rate < 1) {
      color = 'rgba(255, 255, 255, 0.0)'; // transparent
    } else if (rate < 20) {
      color = 'rgba(0, 128, 0, 0.6)'; // Green
    } else if (rate <= 35) {
      color = 'rgba(255, 255, 0, 0.6)'; // Yellow
    } else if (rate <= 50) {
      color = 'rgba(255, 165, 0, 0.6)'; // Orange
    } else {
      color = 'rgba(255, 0, 0, 0.6)'; // Red
    }
  
    return new Style({
      fill: new Fill({ color }),
      stroke: new Stroke({ color: '#333', width: 1 }),
      text: new Text({
        text: rate !== undefined ? rate.toFixed(1) : '',
        font: '12px sans-serif',
        fill: new Fill({ color: '#000' }),
        stroke: new Stroke({ color: '#fff', width: 2 }),
        overflow: false,
      }),
    });
  },
    
  boundaryLayerStyleFunction(feature) {
    feature.get("fcode"); //update to show custom feature styling
    return new Style({
      fill: new Fill({ color: 'rgba(255, 255, 255, 0.2)' }),
      stroke: new Stroke({ color: '#333', width: 0.3 }),
    });
  },

  clusterLayerStyleFunction(feature) {
    const size = feature.get('features').length;
    
    // Define colors based on size
    let fillColor, textColor;

    if (size > 70) {
      fillColor = '#cc0000'; // Red for > 70
      textColor = '#fff';
    } else if (size > 50) {
      fillColor = '#ff6600'; // Orange for 51–70
      textColor = '#fff';
    } else if (size > 20) {
      fillColor = '#cc9900'; // Yellow for 21–50
      textColor = '#fff';
    } else {
      fillColor = '#339966'; // Green for 0–20
      textColor = '#fff';
    }

    const style = new Style({
        image: new CircleStyle({
            radius: Math.min(8 + size, 20),
            stroke: new Stroke({
                color: '#fff'
            }),
            fill: new Fill({
                color: fillColor // Use the color based on size
            })
        }),
        text: new Text({
            text: size > 1 ? size.toString() : '1',
            fill: new Fill({
                color: textColor
            })
        })
    });

    return style;
  },

  async fetchData({ url, method = 'GET', params = null, callback }) {
    try {
      const token = Utils.getValidToken();
      if (!token) {
        alert('Please login...');
        window.location.href = '/login';
        return;
      }

      let fullUrl = url;
      const options = {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      };

      if (method === 'GET' && params) {
        const queryString = new URLSearchParams(params).toString();
        if (queryString.trim() !== '') fullUrl += `?${queryString}`;
      } else if (params) {
        options.body = JSON.stringify(params);
      }

      const response = await fetch(fullUrl, options);

      if (!response.ok) {
        const errorDetail = await response.json();
        throw new Error(`Error ${response.status}: ${response.statusText} - ${JSON.stringify(errorDetail)}`);
      }

      const data = await response.json();
      if (callback) callback(data);
      return data;
    } catch (error) {
      console.error('API call failed:', error);
    }
  },

  downloadLayerData(map, layerid, filename = "mapdata.csv") {
    const vectorLayer = map.getLayers().getArray().find(l => l.get(layerid) === 'heatmap');
    const features = vectorLayer?.getSource()?.getFeatures();

    if (!features || features.length === 0) {
      alert("No features to download.");
      return;
    }

    const allKeys = new Set();
    features.forEach(f => {
      const props = f.getProperties();
      for (const k in props) {
        if (k !== 'geometry') allKeys.add(k);
      }
    });

    const headers = Array.from(allKeys);
    const rows = features.map(f => {
      const props = f.getProperties();
      return headers.map(h => JSON.stringify(props[h] ?? "")).join(",");
    });

    const csvContent = `${headers.join(",")}\n${rows.join("\n")}`;
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, filename);
  },

  setLayersVisibility(config, map) {
    const boundaryLayer = map.getLayers().getArray().find(l => l.get(config.layerid) === 'boundary');
    const clusterLayer = map.getLayers().getArray().find(l => l.get(config.layerid) === 'cluster');
    const heatmapLayer = map.getLayers().getArray().find(l => l.get(config.layerid) === 'heatmap');
    const incidenceLayer = map.getLayers().getArray().find(l => l.get(config.layerid) === 'incidence');
        

    if (heatmapLayer)
      heatmapLayer.setVisible(config.map_type === 'heatmap');
    if (clusterLayer)
      clusterLayer.setVisible(config.map_type === 'cluster');
    if (incidenceLayer)
      incidenceLayer.setVisible(config.map_type === 'incidence');      
    if (boundaryLayer)
      boundaryLayer.setVisible(config.boundary);
  },

  handleClusterClick(feature, map, setSelectedCluster) {
    setSelectedCluster({ feature, map });
  },

  handleIncidenceClick(feature, map, setSelectedFeature) {
    setSelectedFeature({ feature, map });
  },

    //handleClusterClick(feature, map, setSelectedCluster) {
    // const features = feature.get('features');
    
    // if (features && features.length > 1) {
    //   // It's a cluster with multiple features
    //   const extent = createEmpty();
    //   features.forEach(f => extend(extent, f.getGeometry().getExtent()));

    //   map.getView().fit(extent, {
    //     duration: 500,
    //     padding: [50, 50, 50, 50],
    //     maxZoom: 16, // prevent zooming in too far
    //   });
    // } else if (features && features.length === 1) {
    //   // Single feature in cluster — zoom to it
    //   const geometry = features[0].getGeometry();
    //   const view = map.getView();
    //   view.animate({
    //     center: geometry.getCoordinates(),
    //     zoom: 14,
    //     duration: 500
    //   });
    // }
    // },
  
};

export default IncidenceMapUtils;


  //create Vector Source to store data features
  //create ClusterSource from Vector Source
  //create HeatmapSource from Vector Source
  //Create VectorLayer, ClusterLayer and Heatmap Lasyer
  //Set Layer visibility

  // async loadIncidenceData(map, config, done) {
  //   const url = config.url;
  //   const boundary_url = config.boundary_url;
  //   console.log(boundary_url);

  //   const params = {
  //     fcodes: config.fcodes,
  //     start_date: config.start_date,
  //     end_date: config.end_date,
  //     admin_level: config.admin_level,
  //   };

  //   //remove prev. layers
  //   map.getLayers().getArray()
  //   .filter(l => l.get(config.layerid))
  //   // .filter(l => {
  //   //   const id = l.get('layerid');
  //   //   return id && id.startsWith(config.layerid);
  //   // })
  //   .forEach(l => map.removeLayer(l));
    
  //   //get boundary
  //   await IncidenceMapUtils.fetchData({
  //     url: boundary_url,
  //     method: 'GET',
  //     callback: (features) => {        
  //       console.log(features);
  //       //data source
  //       const boundaryVectorSource = new VectorSource({
  //           features: new GeoJSON().readFeatures(
  //             { type: 'FeatureCollection', features },
  //             { featureProjection: 'EPSG:3857' }
  //           ),
  //         });  

  //     //boundary layer
  //     const boundaryLayer = new VectorLayer({
  //       source: boundaryVectorSource,
  //       style: IncidenceMapUtils.boundaryLayerStyleFunction,
  //     });

  //     boundaryLayer.set(config.layerid, 'boundary');
  //     map.addLayer(boundaryLayer);    
  //     boundaryLayer.setVisible(config.boundary);

  //     }
  //   });

  //   //get incidence data
  //   await IncidenceMapUtils.fetchData({
  //     url: url,
  //     method: 'POST',
  //     params: params,
  //     callback: (features) => {      
  //       console.log(features);  
  //       //data source
  //       const incidenceVectorSource = new VectorSource({
  //           features: new GeoJSON().readFeatures(
  //             { type: 'FeatureCollection', features },
  //             { featureProjection: 'EPSG:3857' }
  //           ),
  //         });

  //             // heatmap layer
  //       const heatmapLayer = new HeatmapLayer({
  //         source: incidenceVectorSource,
  //         blur: 10,
  //         radius: 5,
  //         weight: (feature) => feature.get('weight') || 1, // Assign weight dynamically to each feature
  //       });

  //       //Cluster source and layer for displaying points
  //       const clusterSource = new ClusterSource({
  //         distance: 40, // Distance in pixels between clusters
  //         source: incidenceVectorSource,
  //       });

  //       const clusterLayer = new VectorLayer({
  //           source: clusterSource,
  //           style: IncidenceMapUtils.clusterStyleFunction,
  //       });

        
  //       heatmapLayer.set(config.layerid, 'heatmap');
  //       clusterLayer.set(config.layerid, 'cluster');
        
        
  //       map.addLayer(heatmapLayer);    
  //       map.addLayer(clusterLayer);

  //       heatmapLayer.setVisible(config.map_type === 'heatmap');
  //       clusterLayer.setVisible(config.map_type === 'cluster');

  //     }
  //   });

  //   done(true);
  // },
