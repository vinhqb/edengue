import { useEffect } from 'react';

/**
 * Hook to handle hover and click interactions on an OpenLayers vector layer.
 *
 * @param {Object} options
 * @param {ol/Map} options.map - The OpenLayers Map instance.
 * @param {string} options.layerId - A unique string identifying the target layer.
 * @param {Function} options.getLayer - A function that returns the OpenLayers Layer object.
 * @param {Function} [options.onHover] - A callback function(feature, coordinate) for pointer hover.
 * @param {Function} [options.onClick] - A callback function(feature, coordinate) for click.
 * @param {boolean} options.active - Whether the interaction should be active.
 */
export default function useLayerInteraction({
  map,
  layerid,
  onClick,
  active,
}) {
 
  useEffect(() => {
    if (!map || !active) return;

    const handleClick = (evt) => {
      if (!onClick) return;
      const layer = map.getLayers().getArray().find(l => l.get('interaction') === layerid);
      if (!layer) return;

      map.forEachFeatureAtPixel(evt.pixel, (feature, layerCandidate) => {
        if (layerCandidate === layer) {
          onClick(feature, map);
        }
      });
    };


    // const handlePointerMove = (evt) => {
    //   let currentFeature = null;
    //   const layer = map.getLayers().getArray().find(l => l.get('interaction') === layerid);

    //   map.forEachFeatureAtPixel(evt.pixel, (feature, layerCandidate) => {
    //     if (layerCandidate === layer) {
    //       currentFeature = feature;
    //       return false;
    //     }
    //   });

    //   // Update cursor
    //   const targetEl = map.getTargetElement();
    //   if (targetEl) {
    //     targetEl.style.cursor = currentFeature ? 'pointer' : '';
    //   }
    // };

    const handlePointerMove = (evt) => {
      let currentFeature = null;
    
      const interactiveLayers = map.getLayers().getArray().filter(
        (l) => ['incidence', 'cluster'].includes(l.get('interaction'))
      );
    
      map.forEachFeatureAtPixel(evt.pixel, (feature, layerCandidate) => {
        if (interactiveLayers.includes(layerCandidate)) {
          currentFeature = feature;
          return true; // Stop after first match
        }
      });
    
      // Update cursor
      const targetEl = map.getTargetElement();
      if (targetEl) {
        targetEl.style.cursor = currentFeature ? 'pointer' : '';
      }
    };
    
    map.on('click', handleClick);
    map.on('pointermove', handlePointerMove);

    return () => {
      map.un('click', handleClick);
      map.un('pointermove', handlePointerMove);
    };
  }, [map, onClick, active, layerid]);
}
