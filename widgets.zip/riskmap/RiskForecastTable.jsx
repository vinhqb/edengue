import React from "react";
import styles from "./styles.module.css"

const RiskForecastTable = ({ featureName, forecastData }) => {
      
    const monthNames = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];


    // Extract and sort unique (month, year) pairs from forecastData
    const forecastDates = forecastData?.map(d => new Date(d.pred_date)) || [];

    const uniqueMonthYears = Array.from(
        new Set(forecastDates.map(d => `${d.getFullYear()}-${d.getMonth()}`))
      ).map(item => {
        const [year, month] = item.split("-");
        return {
          label: monthNames[parseInt(month)], // using monthNames to get the month label
          year: parseInt(year),
          index: parseInt(month),
        };
      });//.sort((a, b) => a.year - b.year || a.index - b.index);

    // Get unique months and years from the forecast data
    const uniqueMonths = Array.from(new Set(uniqueMonthYears.map(item => item.label)));
    const years = Array.from(new Set(uniqueMonthYears.map(item => item.year)));
            
    const getValue = (monthIndex, year, row) => {
        const entry = forecastData?.find(d => {
          const date = new Date(d.pred_date);
          return date.getMonth() === monthIndex && date.getFullYear() === year;
        });
      
        if (!entry) return "";
      
        if (row.compute) {
          return row.compute(entry);
        }
      
        const value = entry?.[row.key];
        return typeof value === "number" ? Math.round(value) : value ?? "";
    };
            
    const dataRows = [
        { label: "pred. mean", key: "pred_case_mean" },
        { label: "75CI", key: "pred_case_75ub" },
        { label: "95CI", key: "pred_case_95ub" },
        { 
            label: "mean+2sd", 
            compute: entry => {
              const mean = entry?.hist_case_mean;
              const std = entry?.hist_case_std;
              return (typeof mean === "number" && typeof std === "number")
                ? Math.round(mean + 2 * std)
                : "";
            }
        },
        { label: "obs. cases", key: "obs_cases" },
        { label: "population", key: "population" },
        { label: "epidemic prob.", key: "outbreak_risk_prob" },
    ];

    return (
        <div className={styles["forecast-table-container"]}>
          {featureName && (
            <h3 className={styles["forecast-table-title"]}>{featureName}</h3>
          )}
          <table className={styles["forecast-table"]}>
            <thead>
              <tr className={styles["forecast-table-month-row"]}>
                <th className={styles["forecast-table-header"]}></th>
                {uniqueMonths.map((month) => (
                <th
                    key={month}
                    colSpan={years.length}  // Span across all unique years
                    className={styles["forecast-table-month-header"]}
                >
                    {month}
                </th>
                ))}              
              </tr>
              <tr className={styles["forecast-table-year-row"]}>
                <th className={styles["forecast-table-header"]}>Years</th>
                {uniqueMonths.map(() =>
                    years.map((year) => (
                        <th
                        key={`${year}`}
                        className={styles["forecast-table-year-header"]}
                        >
                        {year}
                        </th>
                    ))
                    )}
                </tr>
            </thead>
            <tbody>
              {dataRows.map(row => (
                <tr key={row.label}>
                  <td className={styles["forecast-table-label"]}>{row.label}</td>
                  {uniqueMonthYears.map(({ index, year }) => (
                    <td key={`${row.key}-${index}-${year}`}>
                      {getValue(index, year, row)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
            
};

export default RiskForecastTable;
