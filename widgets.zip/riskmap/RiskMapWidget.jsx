import React, { useEffect, useRef, useState, useCallback  } from "react";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import { fromLonLat } from "ol/proj";
import "ol/ol.css";
import { FaCog, FaTimes, FaDownload, FaSyncAlt } from "react-icons/fa";
import RiskMapUtils from "./RiskMapUtils";
import useLayerInteraction from "./LayerInteraction";
import styles from "./styles.module.css"
import RiskForecastTable from "./RiskForecastTable";
import Utils from "../Utils";

// add map legend for each layer
const riskMapLegend = [
  { color: "green", label: "low risk" },
  { color: "yellow", label: "medium risk" },
  { color: "orange", label: "high risk" },
  { color: "red", label: "outbreak risk" },
]
 
const layerLegends = {
  risk: riskMapLegend,
};

const RiskMapWidget = ({ title, onRemove }) => {
    const mapRef = useRef();
    const olMapRef = useRef();
    
    const [configOpen, setConfigOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [selectedFeature, setSelectedFeature] = useState(null);
    

    const [layerConfig, setLayerConfig] = useState({
      layerid: 'risk',
      fcodes: null,
      date: `${new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1).getFullYear()}-${String(new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1).getMonth() + 1).padStart(2, '0')}-01`, 
      horizon: 3, //load all horizons
      t_threshold: 20,
      p_threshold: 0.1,
      map_type: 'risk',
      method: 4,
      forecast_url: Utils.API_BASE_URL + "/forecast/select",
      visible: true, //fire at load
    });

    const [draftConfig, setDraftConfig] = useState(layerConfig);

    const applyLayerConfig = useCallback(() => {
        const layerLoader = RiskMapUtils.loadRiskData;
        setLayerConfig(draftConfig);
        if (olMapRef.current && typeof layerLoader === "function") {
          setLoading(true);

          // Timeout fallback in case data load hangs
          const timeoutId = setTimeout(() => {
            setLoading(false);
            alert(`Loading timeout for layer ${layerConfig.layerid}`);
            console.warn(`Loading timeout for layer ${layerConfig.layerid}`);
          }, 120000); // 120 seconds

          layerLoader(olMapRef.current, draftConfig, (success = true) => {
            clearTimeout(timeoutId);
            setLoading(!success); // Assume false disables loading if fetch fails
          });
        }
      }, [layerConfig, draftConfig]);

      
    useEffect(() => {
      const mapContainer = mapRef.current;
      olMapRef.current = new Map({
        target: mapContainer,
        layers: [new TileLayer({ source: new OSM() })],
        view: new View({
          center: fromLonLat([106.0, 10.0]),
          zoom: 7,
          projection: "EPSG:3857",
        }),
      });
  
      const resizeObserver = new ResizeObserver(() => {
        if (olMapRef.current) olMapRef.current.updateSize();
      });
  
      if (mapContainer) resizeObserver.observe(mapContainer);
  
      return () => {
        if (mapContainer) resizeObserver.unobserve(mapContainer);
        if (olMapRef.current) olMapRef.current.setTarget(null);
      };
    }, []);
  
    // //Set to false to prevent effect from firing on mount
    // const didMountRef = useRef(false);
    // useEffect(() => {
    //   console.log(didMountRef.current);
    //   if (didMountRef.current) {
    //     if (layerConfig.visible) {
    //         applyLayerConfig();
    //       }
    //   } else {
    //     didMountRef.current = true;
    //   }
    // }, [layerConfig, applyLayerConfig]);
      
    useEffect(() => {
      if (layerConfig.visible) {
        applyLayerConfig();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // empty deps = run only on mount

    const handleConfigChange = (e) => {
      const { name, type, value, checked } = e.target;
      const newValue = type === 'checkbox' ? checked : value;
      
      const updatedConfig = {
        ...draftConfig,
        [name]: newValue,
      };
    
      setDraftConfig(updatedConfig); 
      //fore the layer to redraw
      if (olMapRef.current && ["p_threshold", "t_threshold", "method", "horizon"].includes(name)) {
        const layer = olMapRef.current.getLayers().getArray().find(
          l => l.get('layer_id') === draftConfig.layerid
        );
        if (layer) {
          // Force re-evaluate the style function by passing a new function reference
          layer.setStyle((feature) => RiskMapUtils.riskLayerStyleFunction(feature, updatedConfig));

          // Optional but safe: trigger a source change
          layer.getSource().changed();
        }
          
      }
    };
    
    //Add interactions
    useLayerInteraction({
      map: olMapRef.current,
      layerid: 'risk', //enable interaction with cluster
      onClick:  (feature) => RiskMapUtils.handleFeatureClick(feature, setSelectedFeature),
      onHover:  RiskMapUtils.handleFeatureHover,
      getTooltipContent: RiskMapUtils.getFeatureTooltip, 
      active: true,
    });

    return (
      <>
        <div className="widget-header flex items-center justify-between p-2">
          <button
            onClick={() => setConfigOpen(!configOpen)}
            onTouchStart={() => setConfigOpen(!configOpen)}
            className="config-button p-2 rounded-full hover:bg-gray-200 active:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
            title="Configure"
            aria-label="Configure widget"
          >
            <FaCog className="w-5 h-5" />
          </button>

          <div className="widget-title flex-grow text-center">{title}</div>

          <button
            onClick={onRemove}
            onTouchStart={onRemove}
            className="remove-button p-2 rounded-full hover:bg-red-200 active:bg-red-300 focus:outline-none focus:ring-2 focus:ring-red-400"
            title="Remove"
            aria-label="Remove widget"
          >
            <FaTimes className="w-5 h-5" />
          </button>
        </div>
  
        <div className="widget-content" style={{ width: "100%", height: "100%", boxSizing: "border-box" }}>
          {configOpen && (
            <div
              style={{
                marginBottom: "10px",
                background: "#f5f5f5",
                padding: "10px",
                borderRadius: "5px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
                {[
                  { label: "Issue date", name: "date", type: "date", width: "160px" },
                  { label: "Prob. Threshold", name: "p_threshold", min: 0, max: 1, step: 0.1, type: "number", width: "120px" },
                  { label: "Tollerance", name: "t_threshold", min: 0, step: 1, type: "number", width: "80px" },
                ].map(({ label, name, min, max, step, type, width }) => (
                  <div key={name} style={{ display: "flex", flexDirection: "column", width }}>
                    <label>{label}:</label>
                    <input
                      type={type}
                      name={name}
                      value={draftConfig[name] || ""}
                      min={min}
                      max={max}
                      step={step}
                      onChange={handleConfigChange}
                      disabled={loading}
                      style={{ width }}
                    />
                  </div>
                ))}

                <div style={{ display: "flex", flexDirection: "column" }}>
                  <label>Forecast Horizon:</label>
                  <select
                    name="horizon"
                    value={draftConfig.horizon}
                    onChange={handleConfigChange}
                    disabled={loading}
                  >
                    <option value="1">1 month</option>
                    <option value="2">2 months</option>
                    <option value="3">3 months</option>
                  </select>
                </div>

                <div style={{ display: "flex", flexDirection: "column" }}>
                  <label>Method:</label>
                  <select
                    name="method"
                    value={draftConfig.method}
                    onChange={handleConfigChange}
                    disabled={loading}
                  >
                    <option value="1">Prediction mean</option>
                    <option value="2">Absolute score</option>
                    <option value="3">Z-Score</option>
                    <option value="4">Combined</option>
                  </select>
                </div>

                <button
                    onClick={applyLayerConfig}
                    disabled={loading}
                    className="p-2 rounded-full hover:bg-gray-200 transition"
                    title="Refresh Data"
                    >
                    <FaSyncAlt size={16} />
                </button>                
                <button
                  onClick={() => RiskMapUtils.downloadLayerData(olMapRef.current, draftConfig.layerid, "danh_gia_nguy_co.csv")}
                  className="p-2 rounded-full hover:bg-gray-200 transition"
                  title="Download CSV"
                  disabled={loading}
                >
                  <FaDownload size={16} />
                </button>
              </div>
            </div>
          )}


          {/* <div
            ref={mapRef}
            style={{
              position: "relative",
              width: "100%",
              height: configOpen ? "calc(100% - 75px)" : "100%",
              backgroundColor: "#ddd",
              boxSizing: "border-box",
            }}
          >
            {loading && (
              <div
                style={{
                  position: "absolute",
                  top: 0, left: 0, right: 0, bottom: 0,
                  background: "rgba(255,255,255,0.7)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  zIndex: 1000,
                  fontWeight: "bold",
                }}
              >
                Loading data...
              </div>
            )}
          </div> */}

          <div
            style={{
              display: "flex",
              flexDirection: "row",
              width: "100%",
              height: configOpen ? "calc(100% - 75px)" : "100%",
            }}
          >
            {/* Map Section */}
            <div
              ref={mapRef}
              style={{
                flex: 1,
                position: "relative",
                backgroundColor: "#ddd",
              }}
            >
              {loading && (
                <div
                  style={{
                    position: "absolute",
                    top: 0, left: 0, right: 0, bottom: 0,
                    background: "rgba(255,255,255,0.7)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 1000,
                    fontWeight: "bold",
                  }}
                >
                  Loading data...
                </div>
              )}
            </div>

            {/* Table Section */}
            {selectedFeature && (
              <div
                style={{
                  flex: "0 0 50%",
                  overflowY: "auto",
                  padding: "10px",
                  backgroundColor: "#fff",
                  borderLeft: "1px solid #ccc",
                }}
              >
                <RiskForecastTable featureName={selectedFeature.name} forecastData={selectedFeature.data} />
              </div>
            )}
          </div>
        </div>

        <div className={styles["map-legend"]}>
          {layerLegends[draftConfig.map_type]?.map(({ color, label }, idx) => (
              <div key={idx}>
                <span className={styles["legend-color"]} style={{ backgroundColor: color }}></span> {label}
              </div>
          ))}        
        </div>  

      </>
    );
  };
  
  export default RiskMapWidget;
  