// utils/mapUtils.js
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector'
//import { createEmpty, extend } from 'ol/extent';

import Utils from "../Utils"
//import { Style, Fill, Stroke } from 'ol/style';
import Style from 'ol/style/Style';
import Text from 'ol/style/Text';
import Fill from 'ol/style/Fill';
import Stroke from 'ol/style/Stroke';
import CircleStyle from 'ol/style/Circle';

import { saveAs } from 'file-saver';
import GeoJSON from 'ol/format/GeoJSON';

const RiskMapUtils = {

  async loadRiskData(map, config, done) {

    function getDateRange(date) {
      const dateobj = new Date(date);
      const startOfMonth = new Date(dateobj.getFullYear(), dateobj.getMonth(), 1);
  
      const formatDate = (d) => d.toISOString().split("T")[0];
  
      return {
        start_date: formatDate(startOfMonth),
        end_date: formatDate(dateobj),
      };
    };
  
    const { start_date, end_date } = getDateRange(config.date);

    const params = {
      fcodes: config.fcodes,
      start_date: start_date,
      end_date: end_date,
      forcast_horizon: 0, //load all horizon
      admin_level: config.admin_level,
    };
  
    // Remove previous layers with matching config.layerid
    map.getLayers().getArray()
      .filter(l => l.get('layer_id') === config.layerid)
      .forEach(l => map.removeLayer(l));

    // 1. Incidence (risk) layers setup  
    const riskVectorSource = new VectorSource();
    const riskLayer = new VectorLayer({
      source: riskVectorSource,
      style: (feature) => RiskMapUtils.riskLayerStyleFunction(feature, config),
    });

    riskLayer.set('layer_id', config.layerid);
    //enable layer interaction
    riskLayer.set('interaction', true); 
    map.addLayer(riskLayer);
    
    // --- Fetch and populate forecast data ---
    await RiskMapUtils.fetchData({
      url: config.forecast_url,
      method: 'POST',
      params: params,
      callback: (features) => {
        const riskFeatures = new GeoJSON().readFeatures(
          { type: 'FeatureCollection', features },
          { featureProjection: 'EPSG:3857' }
        );
        riskVectorSource.clear();
        riskVectorSource.addFeatures(riskFeatures);
      }
    });
  
    done(true);
  },
    
  riskLayerStyleFunction : (feature, config) => {
    const forecast = feature.get('forecast') || {};

    let forecastData = {};
    if (config.horizon === 0) {
      const data = forecast?.data || [];
      forecastData = data[data.length - 1] || {};
    } else {
      forecastData = forecast?.data?.[config.horizon - 1] || {};
    }

    const {
      high_risk_threshold = 0,
      medium_risk_threshold = 0,
      low_risk_threshold = 0,
      pred_case_mean = 0,
      risk_abs_value = 0,
      risk_zcore_value = 0,
      risk_abs_prob = 0,
      risk_zcore_prob = 0,      
    } = forecastData;    
    
    const methodMap = {
      1: pred_case_mean,
      2: risk_abs_value,
      3: risk_zcore_value,
    };

    const probMap = {
      1: 0,
      2: risk_abs_prob,
      3: risk_zcore_prob,
    };

    const risk_value = methodMap[config.method] ?? Math.max(pred_case_mean, risk_abs_value, risk_zcore_value);
    const risk_prob = probMap[config.method] ?? 0;

    let risk = risk_value < low_risk_threshold ? 1 :
               risk_value < medium_risk_threshold ? 2 :
               risk_value < high_risk_threshold ? 3 : 4;
    
    if ((risk_value < config.t_threshold) && (risk_prob < config.p_threshold))
      risk = 1;
    
    const riskColors = {
      1: 'rgba(0, 128, 0, 0.6)',      // Green
      2: 'rgba(255, 255, 0, 0.77)',    // Yellow
      3: 'rgba(255, 174, 0, 0.73)',    // Orange
      4: 'rgba(248, 15, 7, 0.67)',    // Orange
      default: 'rgba(255, 255, 255, 0.9)',
    };
    
    const color = riskColors[risk] || riskColors.default;

    return new Style({
      fill: new Fill({ color }),
      stroke: new Stroke({ color: '#333', width: 1 }),
      text: new Text({
        text: risk !== undefined ? Math.round(risk_value) : '',
        font: '12px sans-serif',
        fill: new Fill({ color: '#000' }),
        stroke: new Stroke({ color: '#fff', width: 2 }),
        overflow: false,
      }),
    });
  },
    
  boundaryLayerStyleFunction(feature) {
    feature.get("fcode"); //update to show custom feature styling
    return new Style({
      fill: new Fill({ color: 'rgba(255, 255, 255, 0.2)' }),
      stroke: new Stroke({ color: '#333', width: 0.3 }),
    });
  },

  clusterLayerStyleFunction(feature) {
    const size = feature.get('features').length;
    
    // Define colors based on size
    let fillColor, textColor;

    if (size > 70) {
      fillColor = '#cc0000'; // Red for > 70
      textColor = '#fff';
    } else if (size > 50) {
      fillColor = '#ff6600'; // Orange for 51–70
      textColor = '#fff';
    } else if (size > 20) {
      fillColor = '#cc9900'; // Yellow for 21–50
      textColor = '#fff';
    } else {
      fillColor = '#339966'; // Green for 0–20
      textColor = '#fff';
    }

    const style = new Style({
        image: new CircleStyle({
            radius: Math.min(8 + size, 20),
            stroke: new Stroke({
                color: '#fff'
            }),
            fill: new Fill({
                color: fillColor // Use the color based on size
            })
        }),
        text: new Text({
            text: size > 1 ? size.toString() : '1',
            fill: new Fill({
                color: textColor
            })
        })
    });

    return style;
  },

  async fetchData({ url, method = 'GET', params = null, callback }) {
    try {
      const token = Utils.getValidToken();
      if (!token) {
        alert('Please login...');
        window.location.href = '/login';
        return;
      }

      let fullUrl = url;
      const options = {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      };

      if (method === 'GET' && params) {
        const queryString = new URLSearchParams(params).toString();
        if (queryString.trim() !== '') fullUrl += `?${queryString}`;
      } else if (params) {
        options.body = JSON.stringify(params);
      }

      const response = await fetch(fullUrl, options);

      if (!response.ok) {
        const errorDetail = await response.json();
        throw new Error(`Error ${response.status}: ${response.statusText} - ${JSON.stringify(errorDetail)}`);
      }

      const data = await response.json();
      if (callback) callback(data);
      return data;
    } catch (error) {
      console.error('API call failed:', error);
    }
  },

  downloadLayerData(map, layerid, filename = "mapdata.csv") {
    const vectorLayer = map.getLayers().getArray().find(l => l.get(layerid) === 'heatmap');
    const features = vectorLayer?.getSource()?.getFeatures();

    if (!features || features.length === 0) {
      alert("No features to download.");
      return;
    }

    const allKeys = new Set();
    features.forEach(f => {
      const props = f.getProperties();
      for (const k in props) {
        if (k !== 'geometry') allKeys.add(k);
      }
    });

    const headers = Array.from(allKeys);
    const rows = features.map(f => {
      const props = f.getProperties();
      return headers.map(h => JSON.stringify(props[h] ?? "")).join(",");
    });

    const csvContent = `${headers.join(",")}\n${rows.join("\n")}`;
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, filename);
  },


  handleFeatureClick: async (feature, setSelectedFeature) => {
    function getDateRange(dateStr, nYears) {
      const endDate = new Date(dateStr);
      const startDate = new Date(endDate);
      startDate.setFullYear(endDate.getFullYear() - nYears);
  
      const formatDate = (date) => date.toISOString().split("T")[0];
  
      return {
        start_date: formatDate(startDate),
        end_date: formatDate(endDate),
      };
    }
  
    const forecast = feature.get("forecast");
    const featureName = feature.get("address")?.postal;
    const fcode = feature.get("fcode");
    const admin_level = feature.get("administrative_level");
    const { start_date, end_date } = getDateRange(forecast.issue_date, 2);
  
    const params = {
      fcodes: [fcode],
      start_date,
      end_date,
      forecast_horizon: 0, // Load all horizons
      admin_level,
    };
      
    await RiskMapUtils.fetchData({
      url: Utils.API_BASE_URL + '/forecast/history',
      method: 'POST',
      params,
      callback: (features) => {
        setSelectedFeature({
          data: features[fcode],
          name: featureName,
        });
      }
    });
  },

  handleFeatureClick1: async (feature, setSelectedFeature) => {    
    const forecast = feature.get("forecast");
    const featureName = feature.get("address")['postal'];

    if (forecast?.data) {
      setSelectedFeature({
        data: forecast.data,     // The forecast data
        name: featureName        // The feature name (or any other relevant info)
      });
    }
  },

  getFeatureTooltip(feature) {
    const name = feature.get('address')['postal'] || 'Unknown';
    const prob = feature.get('forecast').data[0].outbreak_risk_prob * 100;
    return `
      <div style="font-family: sans-serif; padding: 4px 8px;">
        <div style="font-weight: bold; font-size: 14px; margin-bottom: 2px;">${name}</div>
        <div style="font-size: 13px; color: #555;">Outbreak probability: <span style="font-weight: bold; color: #c00;">${prob.toFixed(1)} %</span></div>
      </div>
    `;
  },

}

export default RiskMapUtils;