import React, { useEffect, useState } from "react";
import styles from "./styles.module.css";
import { FaCog, FaSyncAlt, FaDownload, FaTimes } from "react-icons/fa";

import {
  LineChart,
  AreaChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  ResponsiveContainer,
  Area
} from "recharts";
import Utils from "../Utils";


const DenguePlotWidget = ({ title, onRemove }) => {
  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [communes, setCommunes] = useState([]);
  const [selectedProvince, setSelectedProvince] = useState("");
  const [selectedDistrict, setSelectedDistrict] = useState("");
  const [selectedCommune, setSelectedCommune] = useState("");
  const [startDate, setStartDate] = useState(new Date(new Date().setFullYear(new Date().getFullYear() - 1)).toISOString().split("T")[0]);
  const [endDate, setEndDate] = useState((new Date()).toISOString().split("T")[0]);
  const [horizon, setForecastHorizon] = useState(3);
  const [plot_type, setPlotType] = useState(1);
  const [loading, setLoading] = useState(false);
  const [chartData, setChartData] = useState([]);
  const [configOpen, setConfigOpen] = useState(true);

  const fetchProvinces = async () => {
    try {
      const response = await fetch(`${Utils.API_BASE_URL}/boundary/provinces/list`);
      const data = await response.json();
      setProvinces(data);
    } catch (error) {
      console.error("Error fetching provinces:", error);
    }
  };

  const fetchDistricts = async (province) => {
    try {
      const response = await fetch(`${Utils.API_BASE_URL}/boundary/districts/list?province=${province}`);
      const data = await response.json();
      setDistricts(data);
      setSelectedDistrict("");
      setSelectedCommune("");
      setCommunes([]);
    } catch (error) {
      console.error("Error fetching districts:", error);
    }
  };

  const fetchCommunes = async (district, province) => {
    try {
      const response = await fetch(`${Utils.API_BASE_URL}/boundary/communes/list?district=${district}&province=${province}`);
      const data = await response.json();
      setCommunes(data);
      setSelectedCommune("");
    } catch (error) {
      console.error("Error fetching communes:", error);
    }
  };


  const removeVietnameseDiacritics = (str) => {
    return str
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // Remove diacritics
      .replace(/đ/g, "d")
      .replace(/Đ/g, "D")
      .replace(/\s+/g, "_") // Replace spaces with underscores
      .toUpperCase();
  };

  const detectDistrictSuffix = (districtName) => {
    const lower = districtName.toLowerCase();
    if (lower.startsWith("huyện")) return "_DISTRICT";
    if (lower.startsWith("quận")) return "_URBAN_DISTRICT";
    if (lower.startsWith("thị xã") || lower.startsWith("thị trấn")) return "_TOWN";
    return "";
  };

  const stripVietnameseAdminPrefix = (name) => {
    return name
      .replace(/^(Tỉnh|Thành phố|TP|Quận|Huyện|Thị xã|Thị Trấn|Phường|Xã)\s+/i, '')
      .trim();
  };

  const sanitizeLocationName = (name) => {
    return removeVietnameseDiacritics(stripVietnameseAdminPrefix(name));
  };

  const formulateFcodes = () => {
    if (selectedDistrict) {
      const suffix = detectDistrictSuffix(selectedDistrict);
      const fcode = `ED_${sanitizeLocationName(selectedProvince)}_${sanitizeLocationName(selectedDistrict)}${suffix}`;
      return [fcode];
    } else if (selectedProvince) {
      return districts.map((district) => {
        const suffix = detectDistrictSuffix(district);
        return `ED_${sanitizeLocationName(selectedProvince)}_${sanitizeLocationName(district)}${suffix}`;
      });
    }
    return [];
  };

  const fetchDengueData = async () => {
    if (!selectedProvince || !startDate || !endDate) return;

    const fcodes = formulateFcodes();
    if (fcodes.length === 0) return;

    try {
      setLoading(true);
      const response = await fetch(`${Utils.API_BASE_URL}/cases/monthly`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          fcodes: fcodes,
          start_date: startDate,
          end_date: endDate
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      

      const formattedData = (() => {
        const dataDict = {};

        data.forEach(entry => {
          const { year, month, obs_dengue_cases, severe_dengue_cases,           
                  ws_avg, ws_max, ws_min, t2m_avg, t2m_max, t2m_min, rh_avg, rh_max, rh_min, tp_accum,
                  forecast } = entry;

          // Key for observed data: MM-YYYY
          const observedKey = `${String(month).padStart(2, '0')}-${year}`;
          if (!dataDict[observedKey]) {
            dataDict[observedKey] = {
              date: observedKey,
            };
          }

          // Fill observed values
          dataDict[observedKey].obs_dengue_cases = obs_dengue_cases ?? null;
          dataDict[observedKey].severe_dengue_cases = severe_dengue_cases ?? null;
          //wind speed
          dataDict[observedKey].ws_avg = ws_avg ?? null;
          dataDict[observedKey].ws_max = ws_max ?? null;
          dataDict[observedKey].ws_min = ws_min ?? null;
          //temp
          dataDict[observedKey].t2m_avg = t2m_avg != null ? t2m_avg - 273.15 : null;
          dataDict[observedKey].t2m_max = t2m_max != null ? t2m_max - 273.15 : null;
          dataDict[observedKey].t2m_min = t2m_min != null ? t2m_min - 273.15 : null;
          //humidity
          dataDict[observedKey].rh_avg = rh_avg ?? null;
          dataDict[observedKey].rh_max = rh_max ?? null;
          dataDict[observedKey].rh_min = rh_min ?? null;
          //precitipation
          dataDict[observedKey].tp_accum = tp_accum ?? null;

          // Forecast logic: include only matching horizon
          const matchingForecast = forecast?.data?.find(f => f.forecast_horizon === horizon);
          if (matchingForecast) {
            const forecastDate = new Date(matchingForecast.pred_date);            
            const forecastKey = `${String(forecastDate.getMonth() + 1).padStart(2, '0')}-${forecastDate.getFullYear()}`;

            if (!dataDict[forecastKey]) {
              dataDict[forecastKey] = {
                date: forecastKey,
                obs_dengue_cases: null,
                severe_dengue_cases: null,
              };
            }
            if (
              matchingForecast.pred_case_mean != null &&
              matchingForecast.pred_case_95lb != null &&
              matchingForecast.pred_case_95ub != null &&
              !isNaN(matchingForecast.pred_case_mean) &&
              !isNaN(matchingForecast.pred_case_95lb) &&
              !isNaN(matchingForecast.pred_case_95ub)
            ) {
              dataDict[forecastKey].predicted_mean = matchingForecast.pred_case_mean;
              dataDict[forecastKey].predicted_95lb = matchingForecast.pred_case_95lb;
              dataDict[forecastKey].predicted_95ub = matchingForecast.pred_case_95ub;
              dataDict[forecastKey].historical_mean_plus_2std = matchingForecast.hist_case_mean + 2 * matchingForecast.hist_case_std;
            }
          } else {
            console.log("not match:", entry);
          }
        });

        // Return sorted list of values for plotting
        return Object.values(dataDict).sort((a, b) => {
          const [m1, y1] = a.date.split('-').map(Number);
          const [m2, y2] = b.date.split('-').map(Number);
          return new Date(y1, m1 - 1) - new Date(y2, m2 - 1);
        });
      })();

      setChartData(formattedData);
      console.log(formattedData);

    } catch (error) {
      console.error("Error fetching dengue data:", error);
    } finally {
      setLoading(false);
    }
  };

  const downloadCSV = () => {
    if (!chartData.length) return;
    const headers = Object.keys(chartData[0]);
    const rows = chartData.map((row) => headers.map((field) => row[field]));
    const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", "dengue_data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleProvinceChange = (e) => {
    setSelectedProvince(e.target.value);
    fetchDistricts(e.target.value);
  };

  const handleDistrictChange = (e) => {
    setSelectedDistrict(e.target.value);
    fetchCommunes(e.target.value, selectedProvince);
  };

  const handleCommuneChange = (e) => {
    setSelectedCommune(e.target.value);
  };

  useEffect(() => {
    fetchProvinces();
  }, []);

  return (
    <>
      <div className="widget-header">
        <button onClick={() => setConfigOpen(!configOpen)} onTouchStart={() => setConfigOpen(!configOpen)} className="config-button" title="Configure">
          <FaCog />
        </button>
        <div className="widget-title">{title}</div>
        <button onClick={onRemove} onTouchStart={onRemove} className="remove-button" title="Remove">
          <FaTimes />
        </button>
      </div>

      <div className="widget-content" style={{ width: "100%", height: "100%", boxSizing: "border-box", display: "flex", flexDirection: "column" }}>
        {configOpen && (
        <div className={styles["location-selector"]}>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>Start Date:</label>
            <input
              className={styles["date-input"]}
              type="date"
              name="start_date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              disabled={loading}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>End Date:</label>
            <input
              className={styles["date-input"]}
              type="date"
              name="end_date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              disabled={loading}
            />
          </div>

          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>Forecast:</label>
            <select
              className={styles.dropdown}
              name="horizon"
              value={horizon}
              onChange={(e) => setForecastHorizon(Number(e.target.value))}
              disabled={loading}
            >
              <option value="1">1 month</option>
              <option value="2">2 months</option>
              <option value="3">3 months</option>
            </select>
          </div>
          
          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>Province:</label>
            <select onChange={handleProvinceChange} value={selectedProvince} className={styles.dropdown}>
              <option value="">Chọn Tỉnh</option>
              {provinces.map((province) => (
                <option key={province} value={province}>{province}</option>
              ))}
            </select>
          </div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>District:</label>
            <select onChange={handleDistrictChange} value={selectedDistrict} disabled={!selectedProvince} className={styles.dropdown}>
              <option value="">Chọn Huyện</option>
              {districts.map((district) => (
                <option key={district} value={district}>{district}</option>
              ))}
            </select>
          </div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>Commune:</label>
            {/* <select onChange={handleCommuneChange} value={selectedCommune} disabled={!selectedDistrict} className={styles.dropdown}> */}
            <select onChange={handleCommuneChange} value={selectedCommune} disabled={true} className={styles.dropdown}>
              <option value="">Chọn Xã</option>
              {communes.map((commune) => (
                <option key={commune} value={commune}>{commune}</option>
              ))}
            </select>
          </div>

          <div style={{ display: "flex", flexDirection: "column" }}>
            <label>Plot:</label>
            <select
              className={styles.dropdown}
              name="plot_type"
              value={plot_type}
              onChange={(e) => setPlotType(Number(e.target.value))}
              disabled={loading}
            >
              <option value="1">Dengue Forecast</option>
              <option value="2">Climate</option>
            </select>
          </div>


          <button onClick={fetchDengueData} disabled={loading} className="p-2 rounded-full hover:bg-gray-200 transition" title="Refresh Data">
            <FaSyncAlt size={16} />
          </button>
          <button onClick={downloadCSV} className="p-2 rounded-full hover:bg-gray-200 transition" title="Download CSV" disabled={loading}>
            <FaDownload size={16} />
          </button>
        </div>
        )}
        <div style={{ flexGrow: 1, padding: 10 }}> 
          {(plot_type === 1) && (
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart
              data={chartData}
              margin={{ top: 50, right: 30, left: 20, bottom: 70 }}
            >
              <CartesianGrid strokeDasharray="3 3" />

              <XAxis
                dataKey="date"
                interval={0}
                angle={-45}
                textAnchor="end"
                tick={{ fontSize: 12 }}
              />
              <YAxis />
              <Tooltip />
              <Legend verticalAlign="top" height={36} />

              {/* 95% Confidence Interval */}
              <Area
                type="monotone"
                dataKey="predicted_95lb"
                stackId="ci95"
                stroke="none"
                fill="transparent"
              />
              <Area
                type="monotone"
                dataKey="predicted_95ub"
                stackId="ci95"
                stroke="none"
                fill="#2196f3"
                fillOpacity={0.15}
                name="95% CI"
              />

              {/* Observed Cases as thin line */}
              <Area
                type="monotone"
                dataKey="obs_dengue_cases"
                stroke="#000"
                strokeWidth={2.5} 
                fill="none"
                name="Observed Cases"
              />

              {/* Severe Cases as thin line */}
              <Area
                type="monotone"
                dataKey="severe_dengue_cases"
                stroke="orange"
                fill="none"
                name="Severe Cases"
              />

              {/* Predicted Mean as dashed line */}
              <Area
                type="monotone"
                dataKey="predicted_mean"
                stroke="#2196f3"
                strokeWidth={2.5} 
                fill="none"
                name="Predicted Mean"
              />

              {/* Historical Mean + 2SD */}
              <Area
                type="monotone"
                dataKey="historical_mean_plus_2std"
                stroke="red"
                strokeDasharray="5 5"
                fill="none"
                name="Hist Mean + 2SD"
              />
            </AreaChart>
          </ResponsiveContainer>
          )}
          {(plot_type === 1) && (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart
              data={chartData}
              margin={{ top: 50, right: 30, left: 20, bottom: 70 }} // More bottom margin
            >
              <CartesianGrid strokeDasharray="3 3" />

              <XAxis
                dataKey="date"
                interval={0}
                angle={-45}
                textAnchor="end"
                tick={{ fontSize: 12 }}
              />
              <YAxis />
              <Tooltip />
              <Legend verticalAlign="top" height={36} /> {/* Moved to top */}
              <Line 
                type="monotone" 
                dataKey="obs_dengue_cases" 
                stroke="#000" 
                strokeWidth={2.5} 
                name="Observed Cases" 
              />
              <Line 
                type="monotone" 
                dataKey="severe_dengue_cases" 
                stroke="orange" 
                name="Severe Cases" />
              <Line
                type="monotone"
                dataKey="predicted_mean"
                stroke="#2196f3"
                strokeWidth={2.5}                 
                name="Predicted Mean"
              />
              <Line
                type="monotone"
                dataKey="historical_mean_plus_2std"
                strokeDasharray="5 5"
                stroke="red"
                name="Hist Mean + 2SD"
              />
            </LineChart>           
          </ResponsiveContainer>
          )}
          {(plot_type === 2) && (
          <>
            {/* Chart 1: Temperature */}
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData} margin={{ top: 50, right: 30, left: 20, bottom: 70 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" angle={-45} textAnchor="end" tick={{ fontSize: 12 }} interval={0} />
                <YAxis unit="°C" />
                <Tooltip />
                <Legend verticalAlign="top" height={36} />
                <Line type="monotone" dataKey="t2m_min" stroke="#00bcd4" name="Temp Min (°C)" />
                <Line type="monotone" dataKey="t2m_avg" stroke="#2196f3" strokeWidth={2.5} name="Temp Avg (°C)" />
                <Line type="monotone" dataKey="t2m_max" stroke="#f44336" name="Temp Max (°C)" />
              </LineChart>
            </ResponsiveContainer>

            {/* Chart 2: Wind Speed */}
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData} margin={{ top: 50, right: 30, left: 20, bottom: 70 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" angle={-45} textAnchor="end" tick={{ fontSize: 12 }} interval={0} />
                <YAxis unit="m/s" />
                <Tooltip />
                <Legend verticalAlign="top" height={36} />
                <Line type="monotone" dataKey="ws_min" stroke="#aed581" name="Wind Min (m/s)" />
                <Line type="monotone" dataKey="ws_avg" stroke="#689f38" strokeWidth={2.5} name="Wind Avg (m/s)" />
                <Line type="monotone" dataKey="ws_max" stroke="#33691e" name="Wind Max (m/s)" />
              </LineChart>
            </ResponsiveContainer>

            {/* Chart 3: Humidity + Precipitation */}
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData} margin={{ top: 50, right: 30, left: 20, bottom: 70 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" angle={-45} textAnchor="end" tick={{ fontSize: 12 }} interval={0} />
                <YAxis yAxisId="left" domain={[0, 100]} unit="%" />
                <YAxis yAxisId="right" orientation="right" unit=" mm" />
                <Tooltip />
                <Legend verticalAlign="top" height={36} />
                <Line yAxisId="left" type="monotone" dataKey="rh_min" stroke="#81d4fa" name="Humidity Min (%)" />
                <Line yAxisId="left" type="monotone" dataKey="rh_avg" stroke="#0288d1" strokeWidth={2.5} name="Humidity Avg (%)" />
                <Line yAxisId="left" type="monotone" dataKey="rh_max" stroke="#01579b" name="Humidity Max (%)" />
                <Line yAxisId="right" type="monotone" dataKey="tp_accum" stroke="#8e24aa" strokeDasharray="5 5" name="Precipitation (mm)" />
              </LineChart>
            </ResponsiveContainer>
          </>
          )}
        </div>
      </div>
    </>
  );
};

export default DenguePlotWidget;
