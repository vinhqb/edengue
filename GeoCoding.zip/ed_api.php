<?php
// Enable error logging
ini_set('log_errors', 1);
ini_set('error_log', './php-error.log');
error_reporting(E_ALL);

include 'ed_db.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet();
        break;
    case 'POST':
        handlePost();
        break;
    case 'PUT':
        handlePut();
        break;
    case 'DELETE':
        handleDelete();
        break;
    default:
        echo json_encode(["message" => "Unsupported method"]);
}

function handleGet() {
    global $conn;
    $params = [];
    $sql = "SELECT * FROM ED_CaseAddress WHERE 1=1";

    if (isset($_GET['InDate'])) {
        $sql .= " AND InDate = ?";
        $params[] = $_GET['InDate'];
    }
    if (isset($_GET['OutDate'])) {
        $sql .= " AND OutDate = ?";
        $params[] = $_GET['OutDate'];
    }
    if (isset($_GET['L3Addr'])) {
        $sql .= " AND L3Addr = ?";
        $params[] = $_GET['L3Addr'];
    }
    if (isset($_GET['L2Addr'])) {
        $sql .= " AND L2Addr = ?";
        $params[] = $_GET['L2Addr'];
    }
    if (isset($_GET['L1Addr'])) {
        $sql .= " AND L1Addr = ?";
        $params[] = $_GET['L1Addr'];
    }
    if (isset($_GET['L0Addr'])) {
        $sql .= " AND L0Addr = ?";
        $params[] = $_GET['L0Addr'];
    }
    if (isset($_GET['Type'])) {
        $sql .= " AND Type = ?";
        $params[] = $_GET['Type'];
    }

    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param(str_repeat("s", count($params)), ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($data);
}

function handlePost() {
    global $conn;
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $conn->prepare("INSERT INTO ED_CaseAddress (CID, InDate, OutDate, L3Addr, L2Addr, L1Addr, L0Addr, POAddr, Latitude, Longitude, Type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssdds", $data['CID'], $data['InDate'], $data['OutDate'], $data['L3Addr'], $data['L2Addr'], $data['L1Addr'], $data['L0Addr'], $data['POAddr'], $data['Latitude'], $data['Longitude'], $data['Type']);
    if ($stmt->execute()) {
        echo json_encode(["message" => "Record created successfully"]);
    } else {
        echo json_encode(["message" => "Error: " . $stmt->error]);
    }
}

function handlePut() {
    global $conn;
    parse_str(file_get_contents("php://input"), $data);
    $stmt = $conn->prepare("UPDATE ED_CaseAddress SET InDate=?, OutDate=?, L3Addr=?, L2Addr=?, L1Addr=?, L0Addr=?, POAddr=?, Latitude=?, Longitude=?, Type=? WHERE CID=?");
    $stmt->bind_param("ssssssssdds", $data['InDate'], $data['OutDate'], $data['L3Addr'], $data['L2Addr'], $data['L1Addr'], $data['L0Addr'], $data['POAddr'], $data['Latitude'], $data['Longitude'], $data['Type'], $data['CID']);
    if ($stmt->execute()) {
        echo json_encode(["message" => "Record updated successfully"]);
    } else {
        echo json_encode(["message" => "Error: " . $stmt->error]);
    }
}

function handleDelete() {
    global $conn;
    $cid = $_GET['CID'];
    $stmt = $conn->prepare("DELETE FROM ED_CaseAddress WHERE CID = ?");
    $stmt->bind_param("s", $cid);
    if ($stmt->execute()) {
        echo json_encode(["message" => "Record deleted successfully"]);
    } else {
        echo json_encode(["message" => "Error: " . $stmt->error]);
    }
}
?>
