<?php
$servername = "localhost";
$username = "edenguec_dba"; // Change to your database username
$password = "sotxuathuyet2004!"; // Change to your database password
$dbname = "edenguec_casedb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>