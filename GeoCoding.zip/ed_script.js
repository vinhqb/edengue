document.addEventListener('DOMContentLoaded', function() {
    const apiUrl = 'ed_api.php';
    const nominatimUrl = 'https://nominatim.openstreetmap.org/search';
    let currentGeocodingItem = null;

    const saveBtn = document.getElementById('save-btn');
    const deleteBtn = document.getElementById('delete-btn');
    const filterBtn = document.getElementById('filter-btn');
    const geocodeSelectedBtn = document.getElementById('geocode-selected-btn');
    const geocodeAllBtn = document.getElementById('geocode-all-btn');
    const itemsList = document.getElementById('items-list');
    const map = new ol.Map({
        target: 'map',
        layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
        ],
        view: new ol.View({
            center: ol.proj.fromLonLat([0, 0]),
            zoom: 2
        })
    });

    // CRUD Operations
    function createItem(data) {
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        }).then(response => response.json())
          .then(data => {
              alert(data.message);
              readItems(); // Refresh the map and list after saving
          });
    }

    function updateItem(data) {
        fetch(apiUrl, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        }).then(response => response.json())
          .then(data => {
              alert(data.message);
              readItems(); // Refresh the map and list after updating
          });
    }

    function deleteItem(cid) {
        fetch(`${apiUrl}?CID=${cid}`, {
            method: 'DELETE'
        }).then(response => response.json())
          .then(data => {
              alert(data.message);
              readItems(); // Refresh the map and list after deleting
          });
    }

    function readItems() {
        const params = new URLSearchParams(new FormData(document.getElementById('filter-form'))).toString();
        fetch(`${apiUrl}?${params}`, {
            method: 'GET'
        }).then(response => response.json())
          .then(data => {
              updateItemsList(data);
              addMarkers(data);
          });
    }

    function updateItemsList(items) {
        itemsList.innerHTML = '';

        items.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `CID: ${item.CID}, PO Address: ${item.POAddr}`;
            li.dataset.cid = item.CID;
            li.dataset.index = items.indexOf(item);
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'item-checkbox';
            li.prepend(checkbox);
            itemsList.appendChild(li);
        });
    }

    function addMarkers(items) {
        const vectorSource = new ol.source.Vector();
        items.forEach(item => {
            if (item.Latitude && item.Longitude) {
                const feature = new ol.Feature({
                    geometry: new ol.geom.Point(ol.proj.fromLonLat([item.Longitude, item.Latitude])),
                    type: item.Type
                });
                vectorSource.addFeature(feature);
            }
        });

        const vectorLayer = new ol.layer.Vector({
            source: vectorSource,
            style: function(feature) {
                const type = feature.get('type');
                return new ol.style.Style({
                    image: new ol.style.Circle({
                        radius: 10,
                        fill: new ol.style.Fill({ color: type === 0 ? 'red' : type === 1 ? 'blue' : type === 2 ? 'green' : 'yellow' })
                    })
                });
            }
        });

        map.addLayer(vectorLayer);
    }

    function geocodeAddress(poAddr) {
        return fetch(`${nominatimUrl}?q=${encodeURIComponent(poAddr)}&format=json&addressdetails=1`)
            .then(response => response.json())
            .then(data => {
                if (data.length > 0) {
                    return {
                        lat: parseFloat(data[0].lat),
                        lon: parseFloat(data[0].lon)
                    };
                } else {
                    throw new Error('Geocoding failed');
                }
            });
    }

    function promptForManualGeocoding(item) {
        currentGeocodingItem = item;
        const message = `Failed to geocode address: ${item.POAddr}. Please select the location on the map.`;
        showGeocodingStatus(message);
        map.once('click', function(event) {
            const coords = ol.proj.toLonLat(event.coordinate);
            item.Latitude = coords[1];
            item.Longitude = coords[0];
            updateItem(item);
            addMarkers([item]); // Add the newly geocoded item to the map
            currentGeocodingItem = null; // Reset current item
            showGeocodingStatus('Geocoding complete');
        });
    }

    function showGeocodingStatus(message) {
        const statusDiv = document.getElementById('geocoding-status');
        statusDiv.textContent = `Status: ${message}`;
    }

    function geocodeAndSaveItems(items) {
        let index = 0;

        function geocodeNext() {
            if (index >= items.length) return;
            const item = items[index];
            if (!item.Latitude || !item.Longitude) {
                showGeocodingStatus(`Geocoding item: ${item.POAddr}`);
                geocodeAddress(item.POAddr).then(coords => {
                    item.Latitude = coords.lat;
                    item.Longitude = coords.lon;
                    updateItem(item);
                    addMarkers([item]); // Add the newly geocoded item to the map
                    index++;
                    setTimeout(geocodeNext, 1000);  // Rate limit to 1 item per second
                }).catch(error => {
                    console.error('Geocoding error:', error);
                    promptForManualGeocoding(item);
                    index++;
                });
            } else {
                index++;
                geocodeNext();
            }
        }

        geocodeNext();
    }

    function getSelectedItems() {
        const checkboxes = document.querySelectorAll('.item-checkbox');
        const selectedItems = [];
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const li = checkbox.parentElement;
                const cid = li.dataset.cid;
                selectedItems.push(cid);
            }
        });
        return selectedItems;
    }

    // Event Listeners
    saveBtn.addEventListener('click', function() {
        const data = {
            CID: document.getElementById('CID').value,
            InDate: document.getElementById('InDate').value,
            OutDate: document.getElementById('OutDate').value,
            L3Addr: document.getElementById('L3Addr').value,
            L2Addr: document.getElementById('L2Addr').value,
            L1Addr: document.getElementById('L1Addr').value,
            L0Addr: document.getElementById('L0Addr').value,
            POAddr: document.getElementById('POAddr').value,
            Latitude: document.getElementById('Latitude').value,
            Longitude: document.getElementById('Longitude').value,
            Type: parseInt(document.getElementById('Type').value, 10)
        };
        const id = document.getElementById('form-id').value;
        if (id) {
            data.CID = id;
            updateItem(data);
        } else {
            alert("item created")
            createItem(data);
        }
    });

    deleteBtn.addEventListener('click', function() {
        const cid = document.getElementById('CID').value;
        if (cid) {
            deleteItem(cid);
        } else {
            alert('No CID specified for deletion');
        }
    });

    filterBtn.addEventListener('click', function() {
        readItems();
    });

    geocodeSelectedBtn.addEventListener('click', function() {
        const selectedCIDs = getSelectedItems();
        if (selectedCIDs.length > 0) {
            fetch(`${apiUrl}?CIDs=${selectedCIDs.join(',')}`, {
                method: 'GET'
            }).then(response => response.json())
              .then(data => {
                  geocodeAndSaveItems(data);
              });
        } else {
            alert('No items selected for geocoding');
        }
    });

    geocodeAllBtn.addEventListener('click', function() {
        readItems(); // Refresh filtered items
        setTimeout(() => {
            const items = document.querySelectorAll('#items-list li');
            const allItems = Array.from(items).map(item => ({
                CID: item.dataset.cid,
                POAddr: item.querySelector('input').value
            }));
            geocodeAndSaveItems(allItems);
        }, 1000); // Ensure items are updated before geocoding
    });
});
